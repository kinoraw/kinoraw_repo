# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
#
#
#
#Todo:
#   Possible redo - instead of modal function, replace built-in operators
#       Still figuring out how to do this... can replace an operator by giving it the same bl_idname, but then the original can't be called...
#       Would not be able to detect renames
#       Need to replace:
#           bpy.ops.sequencer.cut
#           bpy.ops.sequencer.duplicate
#           bpy.ops.sequencer.duplicate_move
#           bpy.ops.sequencer.movie_strip_add
#           bpy.ops.sequencer.image_strip_add
#           bpy.ops.sequencer.paste
#           bpy.ops.transform.transform
#           bpy.ops.sequencer.select
#           bpy.ops.sequencer.select_handles
#           bpy.ops.sequencer.select_border
#           bpy.ops.sequencer.select_more
#   Implement QuickOrganizer - 
#       Optimize Channels - move all clips down as far as possible, place video below audio
#       Consolidate Selected - Move all selected strips to one area
#       Auto-Set Timeline - move strips up to frame 1, set timeline start to frame 1, set timeline end to last frame of last strip 
#   Parenting is incorrect when a parent/child pair is copied and pasted or duplicated
#   Improve QuickRipple - 
#       If possible, implement sequence moving (strips auto-adjusted when strip is 'popped' out of the sequence, or dropped in)
#       Ripple delete multiple clips with one not deleted in the middle causes issues - not sure how to get this to work
#       Moving the left handle does not ripple the strip - not sure how to get this to work
#   Reimplement cursor following if it is possible to determine zoom level of the sequencer area - have not figured out how yet
#       This could allow for overlay details or functions as well such as fades, displaying the current zoom window size in minutes/seconds,
#       Also this could allow for remembering previous zoom, and returning to it
#
#Changelog:
#   0.86
#       Fixed transparency in title scenes
#       Fixed no sequences in a scene throwing an error
#       Added auto-parenting of movie sequences with sound
#       Cleaned up quicklist, meta strips now list sub-sequences, effects are indented under the parent sequence
#   0.87
#       Continuous functions should work inside meta strips now
#       Fixed a couple small bugs
#   0.88
#       Added drop shadows to titler
#       Added color picker and material duplicate button to titler
#       Hopefully fixed continuous functions from throwing errors when no strips are loaded
#       Improved adding/changing fades, added a clear fades button
#   0.89
#       Fixed zoom to cursor not working inside meta strips
#       Fixed zoom to cursor not working in Blender 2.74
#       Fixed child sequences being moved twice if they were manually moved along with the parent
#       Recoded continuous function - parenting is more reliable, all cut sequences are detected and parented properly, fades are now moved when a sequence is resized
#       Removed continuous snapping, snapping is now built-in in blender as of 2.73
#       Added quick zoom presets
#       Added settings to hide different Quick panels
#       Added QuickParenting option to auto-select child sequences, also child sequences' endpoints will be moved when a parent is resized if they match up.
#       Added font loading button to QuickTitler
#       Added templates to QuickTitler
#       Added display modes for QuickList
#       Cleaned and commented code
#   0.89.1
#       Removed an extra check in the modal function that wasn't doing anything but slowing down the script
#   0.9
#       Split QuickTitling off into its own addon
#       Cleaned up variables
#       Improved child sequence auto-select: handle selections are now duplicated as well
#       Parenting is now stored in a sequence variable of .parent
#       Rewrote continuous modal operator to hopefully fix incorrect detections of add/cut/resize/move
#       Now uses addon preferences to enable or disable features (list, fades and parenting)
#       Edit panel displays fade in/out
#       Parenting panel is simplified and merged into the edit panel
#       Improved crossfade adding
#       Added Quickproxy to automatically enable proxies on imported sequences
#       Added Quickmarkers to add markers to the timeline with a preset name
#       Rewrote the continuous function AGAIN, to now be a handler - this means movement/resizing of child clips is now in real-time, and fades are continuously updated.  Also, switching scenes shouldn't have any adverse affect on the script.
#       New variables added to sequence strips to help track changes: .last_frame_final_start, .last_frame_start, .last_frame_final_duration, .last_select, and .new
#       Child sequences can now be automatically deleted when deleting a parent
#       Renaming a clip should now fix the relationships
#       QuickRipple implemented to enable timeline ripple-style editing, still new and buggy
#       Improved performance by only checking sequences in current editing scope (not checking sequences inside meta strips if not in that meta strip)
#   0.91
#       Added QuickBatchRender to automatically separately render out sequences.  Still in beta, needs testing.
#       Fixed custom zooms freaking out ripple mode
#       Added option to correct the active strip when cutting (if you cut with mouse on the right, active strip remains on left even tho right is selected)
#       Updated panel layouts a bit
#       Fixed ripple thinking meta-ed strips are deleted
#       Ripple delete now moves the cursor with moved strips
#       Ripple delete should now preserve strip channels when possible
#       Child strips now try to follow vertical movement of parent strips, but still get pushed out of the way by other strips
#       Fixed zoom presets being wrong sometimes
#       Moved some settings around to streamline panels a bit
#       Fixed QuickList time index display
#   0.92
#       Added QuickTags for adding metadata text tags to strips
#       Reworked QuickList interface
#       Added reverse sorting in QuickList
#       Added ability to switch strip with previous/next in QuickList
#       Revamped QuickMarkers UI, also adding a marker over a current marker will now rename the current marker
#       Added QuickCuts, a panel and menu for specialized cutting operations and easy timeline adjustments
#       More code cleanup and documentation of functions and classes
#       Reworked frame skipping, can now play in reverse when active, and should work better with slow playback

import bpy
import math
import os
from bpy.app.handlers import persistent


bl_info = {
    "name": "VSE Quick Functions",
    "description": "Improves functionality of the sequencer by adding new menus for snapping, adding fades, zooming, sequence parenting, ripple editing, and playback speed.",
    "author": "Hudson Barkley (Snu)",
    "version": (0, 9, 2),
    "blender": (2, 78, 0),
    "location": "Sequencer Panels; Sequencer Menus; Sequencer S, F, Z, Ctrl-P, Shift-P, Alt-M, Alt-K Shortcuts",
    "wiki_url": "https://wiki.blender.org/index.php/User:Snu/Extensions:2.6/Py/Scripts/Sequencer/VSEQuickFunctions",
    "category": "Sequencer"
}


#Miscellaneous Functions
def find_crossfade(sequences, first_sequence, second_sequence):
    for sequence in sequences:
        if hasattr(sequence, 'input_1') and hasattr(sequence, 'input_2'):
            if (sequence.input_1 == first_sequence and sequence.input_2 == second_sequence) or (sequence.input_2 == first_sequence and sequence.input_1 == second_sequence):
                return sequence
    return False

def overlap_sequences(sequences, frame_start, frame_end):
    """Iterates through sequences and returns a list of all sequences that are partially or wholly within the given frames.
    Arguments:
        sequences: List of VSE Sequence objects to check
        frame_start: Start of the period to look for sequences in
        frame_end: End of the period to look for sequences in
        
    Returns: A list of all sequences within the range, empty if none found."""
    
    overlapping = []
    for sequence in sequences:
        if (sequence.frame_final_end > frame_start and sequence.frame_final_start < frame_end):
            overlapping.append(sequence)
    return overlapping

def under_cursor(sequence, frame):
    """Check if a sequence is visible on a frame
    Arguments:
        sequence: VSE sequence object to check
        frame: Integer, the frame number
    
    Returns: True or False"""
    if sequence.frame_final_start < frame and sequence.frame_final_end > frame:
        return True
    else:
        return False

def edit_panel(self, context):
    """Used to add extra information and variables to the VSE 'Edit Strip' panel"""
    
    #load up preferences
    if __name__ in context.user_preferences.addons:
        prefs = context.user_preferences.addons[__name__].preferences
    else:
        prefs = VSEQFTempSettings()
    
    scene = context.scene
    vseqf = scene.vseqf
    layout = self.layout
    if prefs.fades:
        #display info about the fade in and out of the current sequence
        active_sequence = scene.sequence_editor.active_strip
        fadein = fades(sequence=active_sequence, mode='detect', type='in')
        fadeout = fades(sequence=active_sequence, mode='detect', type='out')
        
        row = layout.row()
        if fadein > 0:
            row.label("Fadein: "+str(round(fadein))+" Frames")
        else:
            row.label("No Fadein Detected")
        if fadeout > 0:
            row.label("Fadeout: "+str(round(fadeout))+" Frames")
        else:
            row.label("No Fadeout Detected")

    if prefs.parenting:
        #display info about parenting relationships
        sequence = scene.sequence_editor.active_strip
        selected = context.selected_sequences
        if len(scene.sequence_editor.meta_stack) > 0:
            #inside a meta strip
            sequencer = scene.sequence_editor.meta_stack[-1]
        else:
            #not inside a meta strip
            sequencer = scene.sequence_editor
        if hasattr(sequencer, 'sequences'):
            sequences = sequencer.sequences
        else:
            sequences = []

        children = find_children(sequence, sequences=sequences)
        parent = find_parent(sequence)
        
        box = layout.box()
        #List relationships for active sequence
        if parent:
            row = box.row()
            split = row.split(percentage=.8, align=True)
            split.label("Parent: "+parent.name)
            split.operator('vseqf.quickparents', text='', icon="BORDER_RECT").action = 'select_parent'
            split.operator('vseqf.quickparents', text='', icon="X").action = 'clear_parent'
        if (len(children) > 0):
            row = box.row()
            split = row.split(percentage=.8, align=True)
            subsplit = split.split(percentage=.1)
            subsplit.prop(scene.vseqf, 'expanded_children', icon="TRIA_DOWN" if scene.vseqf.expanded_children else "TRIA_RIGHT", icon_only=True, emboss=False)
            subsplit.label("Children: "+children[0].name)
            split.operator('vseqf.quickparents', text='', icon="BORDER_RECT").action = 'select_children'
            split.operator('vseqf.quickparents', text='', icon="X").action = 'clear_children'
            if scene.vseqf.expanded_children:
                index = 1
                while index < len(children):
                    row = box.row()
                    split = row.split(percentage=.1)
                    split.label()
                    split.label(children[index].name)
                    index = index + 1
                
        row = box.row()
        split = row.split()
        if (len(selected) <= 1):
            split.enabled = False
        split.operator('vseqf.quickparents', text='Set Active As Parent').action = 'add'
        row = box.row()
        row.prop(vseqf, 'children', toggle=True)

def draw_quicksettings_menu(self, context):
    """Draws the general settings menu for QuickContinuous related functions"""
    layout = self.layout
    if context.scene.vseqf.continuous_enable:
        #draw submenu only if continuous options are enabled
        layout.menu('vseqf.settings_menu', text="Quick Continuous Settings")
    layout.prop(context.scene.vseqf, 'continuous_enable')

def sequences_after_frame(sequences, frame, add_locked=True, add_parented=True, add_effect=True):
    """Finds sequences after a given frame
    Arguments:
        sequences: List containing the VSE Sequence objects that will be searched
        frame: Integer, the frame to check for sequences following
        add_locked: Boolean, if false, locked sequences will be ignored
        add_parented: Boolean, if false, sequences with a set parent will be ignored
        add_effect: Boolean, if false, sequences of the effect type will be ignored
    
    Returns: A list of VSE Sequence objects"""
    update_sequences = []
    for seq in sequences:
        if seq.frame_final_start >= frame:
            #sequence starts after frame
            if (not seq.lock) or add_locked:
                #always adding locked, or sequence is not locked
                if add_parented or (not find_parent(seq)):
                    #always adding parents, or parent not found
                    if add_effect or (not hasattr(seq, 'input_1')):
                        update_sequences.append(seq)
    return update_sequences

def sequences_between_frames(sequences, start_frame, end_frame, add_locked=True, add_parented=True, add_effect=True):
    """Finds sequences that are visible between two given frames
    Arguments:
        sequences: List containing the VSE Sequence objects that will be searched
        start_frame: Integer, beginning frame number to search at
        end_frame: Integer, ending frame to search at
        add_locked: Boolean, if false, locked sequences will be ignored
        add_parented: Boolean, if false, sequences with a set parent will be ignored
        add_effect: Boolean, if false, sequences of the effect type will be ignored
    
    Returns: A list of VSE Sequence objects"""
    update_sequences = []
    for seq in sequences:
        if seq.frame_final_start >= start_frame and seq.frame_final_end <= end_frame:
            if (not seq.lock) or add_locked:
                #always adding locked, or sequence is not locked
                if add_parented or (not find_parent(seq)):
                    #always adding parents, or parent not found
                    if add_effect or (not hasattr(seq, 'input_1')):
                        update_sequences.append(seq)
    return update_sequences

def find_close_sequence(sequences, selected_sequence, direction, mode='overlap', sounds=False, effects=True, children=True):
    """Finds the closest sequence in one direction to the given sequence
    Arguments:
        sequences: List of sequences to search through
        selected_sequence: VSE Sequence object that will be used as the basis for the search
        direction: String, must be 'next' or 'previous', determines the direction to search in
        mode: String, determines how the sequences are searched
            'overlap': Only returns sequences that overlap selected_sequence
            'channel': Only returns sequences that are in the same channel as selected_sequence
            <any other string>: All sequences are returned
        sounds: Boolean, if False, 'SOUND' sequence types are ignored
        effects: Boolean, if False, effect strips that are applied to another strip are ignored
        children: Boolean, if False, strips that are children of another will be ignored
            
    Returns: VSE Sequence object, or Boolean False if no matching sequence is found"""
    
    overlap_nexts = []
    overlap_previous = []
    nexts = []
    previous = []
    
    #iterate through sequences to find all sequences to one side of the selected sequence
    for current_sequence in sequences:
        #don't bother with sound or effect type sequences
        if (current_sequence.type != 'SOUND') or sounds:
            #check if the sequence is a child of another, ignore if needed
            if not children:
                if find_parent(current_sequence):
                    continue
            #check if the sequence is an effect of the selected sequence, ignore if so
            if hasattr(current_sequence, 'input_1'):
                if current_sequence.input_1 == selected_sequence or not effects:
                    continue
            if hasattr(current_sequence, 'input_2'):
                if current_sequence.input_2 == selected_sequence or not effects:
                    continue
            if current_sequence.frame_final_start >= selected_sequence.frame_final_end:
                #current sequence is after selected sequence
                #dont append if channel mode and sequences are not on same channel
                if (mode == 'channel') & (selected_sequence.channel != current_sequence.channel):
                    pass
                else:
                    nexts.append(current_sequence)
            elif current_sequence.frame_final_end <= selected_sequence.frame_final_start:
                #current sequence is before selected sequence
                #dont append if channel mode and sequences are not on same channel
                if (mode == 'channel') & (selected_sequence.channel != current_sequence.channel):
                    pass
                else:
                    previous.append(current_sequence)

            elif (current_sequence.frame_final_start > selected_sequence.frame_final_start) & (current_sequence.frame_final_start < selected_sequence.frame_final_end) & (current_sequence.frame_final_end > selected_sequence.frame_final_end):
                #current sequence startpoint is overlapping selected sequence
                overlap_nexts.append(current_sequence)
            elif (current_sequence.frame_final_end > selected_sequence.frame_final_start) & (current_sequence.frame_final_end < selected_sequence.frame_final_end) & (current_sequence.frame_final_start < selected_sequence.frame_final_start):
                #current sequence endpoint is overlapping selected sequence
                overlap_previous.append(current_sequence)
    
    nexts_all = nexts + overlap_nexts
    previous_all = previous + overlap_previous
    if direction == 'next':
        if mode == 'overlap':
            if len(overlap_nexts) > 0:
                return min(overlap_nexts, key=lambda overlap: abs(overlap.channel - selected_sequence.channel))
            else:
                #overlap mode, but no overlaps
                return False
        elif mode == 'channel':
            if len(nexts) > 0:
                return min(nexts, key=lambda next: (next.frame_final_start - selected_sequence.frame_final_end))
            else:
                return False
        else:
            if len(nexts_all) > 0:
                return min(nexts_all, key=lambda next: (next.frame_final_start - selected_sequence.frame_final_end))
            else:
                #no next sequences
                return False
    else:
        if mode == 'overlap':
            if len(overlap_previous) > 0:
                return min(overlap_previous, key=lambda overlap: abs(overlap.channel - selected_sequence.channel))
            else:
                return False
        elif mode == 'channel':
            if len(previous) > 0:
                return min(previous, key=lambda prev: (selected_sequence.frame_final_start - prev.frame_final_end))
            else:
                return False
        else:
            if len(previous_all) > 0:
                return min(previous_all, key=lambda prev: (selected_sequence.frame_final_start - prev.frame_final_end))
            else:
                return False

def timecode_from_frames(frame, fps, levels=0, subsecond_type='miliseconds'):
    """Converts a frame number to a standard timecode in the format: HH:MM:SS:FF
    Arguments:
        frame: Integer, frame number to convert to a timecode
        fps: Integer, number of frames per second if using 'frames' subsecond type
        levels: Integer, limits the number of timecode elements:
            1: returns: FF
            2: returns: SS:FF
            3: returns: MM:SS:FF
            4: returns: HH:MM:SS:FF
            0: returns an auto-cropped timecode with no zero elements
        subsecond_type: String, determines the format of the final element of the timecode:
            'miliseconds': subseconds will be divided by 100
            'frames': subseconds will be divvided by the current fps
        
    Returns: A string timecode"""

    #ensure the levels value is sane
    if (levels > 4):
        levels = 4
    
    #set the sub second divisor type
    if (subsecond_type == 'frames'):
        subsecond_divisor = fps
    else:
        subsecond_divisor = 100
    
    #check for negative values
    if frame < 0:
        negative = True
        frame = abs(frame)
    else:
        negative = False
    
    #calculate divisions, starting at largest and taking the remainder of each to calculate the next smaller
    total_hours = math.modf(float(frame)/fps/60.0/60.0)
    total_minutes = math.modf(total_hours[0] * 60)
    remaining_seconds = math.modf(total_minutes[0] * 60)
    hours = int(total_hours[1])
    minutes = int(total_minutes[1])
    seconds = int(remaining_seconds[1])
    subseconds = int(round(remaining_seconds[0] * subsecond_divisor))

    hours_text = str(hours).zfill(2)
    minutes_text = str(minutes).zfill(2)
    seconds_text = str(seconds).zfill(2)
    subseconds_text = str(subseconds).zfill(2)
    
    #format and return the time value
    time = subseconds_text
    if levels > 1 or (levels == 0 and seconds > 0):
        time = seconds_text+'.'+time
    if levels > 2 or (levels == 0 and minutes > 0):
        time = minutes_text+':'+time
    if levels > 3 or (levels == 0 and hours > 0):
        time = hours_text+':'+time
    if negative:
        time = '-'+time
    return time


#Functions related to continuous update
def update_sequence(sequence):
    """Used to update the extra variables stored in a VSE Sequence
    Argument:
        sequence: a VSE Sequence object"""
    sequence.last_frame_final_start = sequence.frame_final_start
    sequence.last_frame_start = sequence.frame_start
    sequence.last_frame_final_duration = sequence.frame_final_duration
    sequence.last_select = sequence.select
    sequence.last_channel = sequence.channel
    sequence.last_name = sequence.name
    sequence.new = False

@persistent
def vseqf_continuous(scene):
    """The main continuously running handler that does most of the real-time stuff
    Arguments:
        scene: the current Scene object"""

    vseqf = scene.vseqf
    if vseqf.continuous_enable:
        #check for the skipping interval (speeds things up some)
        if vseqf.skip_index < scene.vseqf_skip_interval:
            vseqf.skip_index += 1
        elif vseqf.skip_index >= scene.vseqf_skip_interval:
            meta_created = False
            vseqf.skip_index = 0
            
            #get the addon preferences
            if __name__ in bpy.context.user_preferences.addons:
                prefs = bpy.context.user_preferences.addons[__name__].preferences
            else:
                prefs = VSEQFTempSettings()
            
            if scene.sequence_editor:
                if len(scene.sequence_editor.meta_stack) > 0:
                    #inside a meta strip
                    sequencer = scene.sequence_editor.meta_stack[-1]
                else:
                    #not inside a meta strip
                    sequencer = scene.sequence_editor
                if hasattr(sequencer, 'sequences'):
                    sequences = sequencer.sequences
                else:
                    sequences = []
                    
                if vseqf.last_sequencer != str(sequencer):
                    #sequencer was changed (went in/out of a meta strip) only update variables on this loop
                    frame_current = scene.frame_current
                    scene.total_sequences = len(sequences)
                    vseqf.last_sequences.clear()
                    
                    for sequence in sequences:
                        sequence_info = vseqf.last_sequences.add()
                        sequence_info.name = sequence.name
                        sequence_info.frame_final_start = sequence.frame_final_start
                        sequence_info.frame_final_end = sequence.frame_final_end

                    vseqf.last_sequencer = str(sequencer)
                    
                else:
                    new_sequences = []
                    cut_sequences = []
                    cut_to_sequences = []
                    moved_sequences = []
                    resized_sequences = []
                    selected_sequences = []
                    removed_sequences = []
                    renamed_sequences = []
                    copied_sequences = []
                    ignored_sequences = []
                    
                    frame_current = scene.frame_current
                    
                    last_total_sequences = scene.total_sequences
                    total_sequences = len(sequences)
                    if total_sequences > last_total_sequences:
                        added_sequences = True
                        deleted_sequences = False
                    elif total_sequences == last_total_sequences:
                        added_sequences = False
                        deleted_sequences = False
                    else:
                        added_sequences = False
                        deleted_sequences = True
                    scene.total_sequences = total_sequences
                    if deleted_sequences:
                        for last_sequence in vseqf.last_sequences:
                            if last_sequence.name not in sequences:
                                if not last_sequence.ignore_continuous:
                                    removed_sequences.append([last_sequence.name, last_sequence.frame_final_start, last_sequence.frame_final_end, last_sequence.parent, last_sequence.ignore_continuous])
                    
                    vseqf.last_sequences.clear()
                    
                    #need to detect: added, resized, moved, cut
                    for sequence in sequences:
                        sequence_info = vseqf.last_sequences.add()
                        sequence_info.name = sequence.name
                        sequence_info.frame_final_start = sequence.frame_final_start
                        sequence_info.frame_final_end = sequence.frame_final_end
                        sequence_info.ignore_continuous = sequence.ignore_continuous
                        if sequence.parent == 'do_not_ripple':
                            sequence_info.ignore_continuous = True
                        if sequence.ignore_continuous:
                            ignored_sequences.append(sequence)
                        else:
                            if sequence.new:
                                #this sequence has just been added
                                if sequence.type == 'META':
                                    meta_created = True
                                new_sequences.append(sequence)
                                update_sequence(sequence)
                            if sequence.select:
                                selected_sequences.append(sequence)
                            if (sequence.frame_start != sequence.last_frame_start) or (sequence.channel != sequence.last_channel):
                                #this sequence was just moved
                                difference = sequence.frame_start - sequence.last_frame_start
                                channel_difference = sequence.channel - sequence.last_channel
                                moved_sequences.append([sequence, difference,channel_difference])
                            if sequence.frame_final_duration != sequence.last_frame_final_duration:
                                #this sequence was just resized or cut
                                if added_sequences:
                                    #there are more sequences, this must have been cut
                                    if sequence.frame_final_start != sequence.last_frame_final_start:
                                        #this is a cut to sequence
                                        cut_to_sequences.append([sequence, sequence.last_frame_final_start, sequence.last_frame_final_duration])
                                    else:
                                        #this is a cut from sequence
                                        cut_sequences.append([sequence, sequence.last_frame_final_start, sequence.last_frame_final_duration])
                                    if scene.vseqf.fix_active:
                                        if sequence.select and not sequence == scene.sequence_editor.active_strip:
                                            if scene.sequence_editor.active_strip.channel == sequence.channel:
                                                scene.sequence_editor.active_strip = sequence
                                else:
                                    #same number of sequences, this must have been resized
                                    resized_sequences.append([sequence, sequence.last_frame_final_start, sequence.last_frame_final_duration])
                            elif (sequence.last_name != sequence.name) and sequence.last_name:
                                #this sequence was renamed or copied, but not cut
                                if sequence.last_name in sequences:
                                    #last name still exists, must have been copied
                                    copied_sequences.append([sequence, sequence.last_name])
                                else:
                                    renamed_sequences.append([sequence, sequence.last_name])

                        update_sequence(sequence)
                    
                    #Populate selected tags
                    if vseqf.show_selected_tags:
                        vseqf.selected_tags.clear()
                        populate_tags(sequences=selected_sequences, tags=vseqf.selected_tags)
                            
                    #Deal with copied sequences
                    for sequence_info in copied_sequences:
                        sequence, last_name = sequence_info
                        #todo: if both child and parent are copied/pasted, update parenting variable to reflect this
                    
                    #Deal with renamed sequences
                    for sequence_info in renamed_sequences:
                        sequence, last_name = sequence_info
                        children = find_children(last_name, name=True, sequences=sequences)
                        for child in children:
                            child.parent = sequence.name
                    
                    #Deal with moved sequences
                    if prefs.parenting and scene.vseqf.children and not scene.vseqf.select_children:
                        moved_sequences = sorted(moved_sequences, key=lambda x:x[0].frame_final_start)
                        for sequence_info in moved_sequences:
                            #move any child sequences along with the parent, if they are not selected as well
                            sequence, difference, channel_difference = sequence_info
                            if scene.vseqf.ripple:
                                pass
                                #todo: ripple moving clips
                            if sequence.name in sequencer.sequences:
                                children = find_children(sequence, sequences=sequences)
                                for child in children:
                                    child.last_channel = child.channel
                                for child in children:
                                    if not child.select:
                                        if not child.lock:
                                            child.frame_start = child.frame_start + difference
                                for child in children:
                                    if sequence.parent != child.name:
                                        #dont move child if parent/child loop, this causes... issues
                                        if not child.select:
                                            if not child.lock:
                                                position = child.frame_start
                                                child.channel = child.last_channel + channel_difference
                                                child.frame_start = position

                    #Deal with resized sequences
                    if prefs.parenting or prefs.fades or scene.vseqf.ripple:
                        for sequence_info in resized_sequences:
                            sequence, last_frame_final_start, last_frame_final_duration = sequence_info
                            start_frame = last_frame_final_start
                            end_frame = start_frame + last_frame_final_duration
                            if scene.vseqf.ripple:
                                if sequence == scene.sequence_editor.active_strip:
                                    #if ripple mode, move sequences after the resized one up or down the timeline
                                    sequences_to_check = sequencer.sequences

                                    update_sequences = sequences_after_frame(sequences_to_check, end_frame, add_locked=False, add_parented=False, add_effect=False)
                                    if last_frame_final_start != sequence.frame_final_start:
                                        #left handle was changed
                                        duration = sequence.frame_final_start - start_frame
                                        #todo: figure this one out
                                        #sequence.frame_start = sequence.frame_start - duration
                                        #for seq in update_sequences:
                                        #    seq.frame_start = seq.frame_start + duration
                                        #would need to move this sequence as well as all sequences after, but the way the grab operator works makes this impossible to set properly
                                        pass
                                    else:
                                        #right handle was changed, move all sequences after to match
                                        duration = sequence.frame_final_end - end_frame
                                        #cache channels
                                        for seq in update_sequences:
                                            seq.last_channel = seq.channel
                                        for seq in update_sequences:
                                            seq.frame_start = seq.frame_start + duration
                                        for seq in update_sequences:
                                            seq.channel = seq.last_channel
                            if prefs.fades:
                                #Fix fades in sequence if they exist
                                fade_in = fades(sequence, mode='detect', type='in', fade_low_point_frame=start_frame)
                                fade_out = fades(sequence, mode='detect', type='out', fade_low_point_frame=end_frame)
                                if fade_in > 0:
                                    fades(sequence, mode='set', type='in', fade_length=fade_in)
                                if fade_out > 0:
                                    fades(sequence, mode='set', type='out', fade_length=fade_out)
                            
                            if prefs.parenting and scene.vseqf.children and not scene.vseqf.select_children and scene.vseqf.child_edges:
                                #resize children if it has some and their endpoints match the pre-resized endpoints, and fix their fades if needed
                                children = find_children(sequence, sequences=sequences)
                                for child in children:
                                    if not child.ignore_continuous:
                                        #move child start frames
                                        if child.frame_final_start == start_frame:
                                            child.frame_final_start = sequence.frame_final_start
                                            child_fade_in = fades(child, mode='detect', type='in', fade_low_point_frame=start_frame)
                                            if child_fade_in > 0:
                                                fades(child, mode='set', type='in', fade_length=child_fade_in)
                                        #move child end frames
                                        if child.frame_final_end == end_frame:
                                            child.frame_final_end = sequence.frame_final_end
                                            child_fade_out = fades(child, mode='detect', type='out', fade_low_point_frame=end_frame)
                                            if child_fade_out > 0:
                                                fades(child, mode='set', type='out', fade_length=child_fade_out)
                                    #if (sequence.frame_final_start != start_frame and sequence.frame_final_start == child.last_frame_final_start) or (sequence.frame_final_end != end_frame and sequence.frame_final_end == (child.last_frame_final_start+child.last_frame_final_duration)):
                                    #    child.ignore_continuous = True
                                    #    if child in ignored_sequences:
                                    #        ignored_sequences.remove(child)
                                    #else:
                                    #    child.ignore_continuous = False

                    #Deal with new sequences
                    build_proxy_on = []
                    if prefs.parenting or prefs.proxy:
                        for sequence in new_sequences:
                            if prefs.proxy and scene.vseqf.enable_proxy and (sequence.type == "MOVIE" or sequence.type == "SCENE"):
                                build_proxy_on.append(sequence)
                                sequence.use_proxy = True
                                sequence.proxy.build_25 = scene.vseqf.proxy_25
                                sequence.proxy.build_50 = scene.vseqf.proxy_50
                                sequence.proxy.build_75 = scene.vseqf.proxy_75
                                sequence.proxy.build_100 = scene.vseqf.proxy_100
                                sequence.proxy.quality = scene.vseqf.proxy_quality
                            
                            if prefs.parenting and scene.vseqf.autoparent:
                                #auto parent sound sequences to their movie sequence
                                if sequence.type == 'SOUND':
                                    if not sequence.parent:
                                        for seq in new_sequences:
                                            if seq.type == 'MOVIE':
                                                if seq.filepath == sequence.sound.filepath:
                                                    print("Parenting "+sequence.name+" to "+seq.name)
                                                    add_children(seq, [sequence])

                    #Build proxies if needed
                    if scene.vseqf.build_proxy and len(build_proxy_on) > 0:
                        last_selected = bpy.context.selected_sequences
                        for seq in sequences:
                            seq.select = False
                        for sequence in build_proxy_on:
                            sequence.select = True
                                                
                        area = False
                        region = False
                        for screenarea in bpy.context.window.screen.areas:
                            if screenarea.type == 'SEQUENCE_EDITOR':
                                area = screenarea
                                for arearegion in area.regions:
                                    if arearegion.type == 'WINDOW':
                                        region = arearegion
                        if area and region:
                            override = bpy.context.copy()
                            override['area'] = area
                            override['region'] = region
                            bpy.ops.sequencer.rebuild_proxy(override, 'INVOKE_DEFAULT')
                        
                        for seq in sequences:
                            seq.select = False
                        for sequence in last_selected:
                            sequence.select = True

                    #Deal with deleted sequences
                    ripple_sequences = []
                    if not meta_created:
                        for sequence in removed_sequences:
                            name, frame_final_start, frame_final_end, parent, ignore_continuous = sequence
                            if not ignore_continuous:
                                ripple_sequences.append(sequence)
                            if vseqf.delete_children:
                                #delete child sequences if required
                                children = find_children(name, name=True, sequences=sequences)
                                if len(children) > 0:
                                    original_selected = bpy.context.selected_sequences
                                    original_active = scene.sequence_editor.active_strip
                                    for seq in original_selected:
                                        seq.select = False
                                    for child in children:
                                        vseqf.last_sequences[child.name].ignore_continuous = True
                                        child.parent = 'do_not_ripple'
                                        child.select = True
                                    bpy.ops.sequencer.delete()

                                    for select in original_selected:
                                        select.select = True
                                    scene.sequence_editor.active_strip = original_active

                    #Ripple delete sequences
                    if scene.vseqf.ripple and (len(ripple_sequences) > 0):
                        #determine ripple amount
                        start_frame = ripple_sequences[0][1]
                        end_frame = ripple_sequences[0][2]
                        for sequence in ripple_sequences:
                            name, frame_final_start, frame_final_end, parent, ignore_continuous = sequence
                            if frame_final_start < start_frame:
                                #determine starting frame by the starting point of the first deleted strip
                                start_frame = frame_final_start
                            if frame_final_end > end_frame:
                                end_frame = frame_final_end
                        total_length = end_frame - start_frame
                        
                        offset = total_length
                        if scene.frame_current > start_frame:
                            if scene.frame_current - offset > start_frame:
                                scene.frame_current = scene.frame_current - offset
                            else:
                                scene.frame_current = start_frame
                        #move sequences after the deleted one up in the timeline
                        sequences_to_check = sequencer.sequences
                        update_sequences = sequences_after_frame(sequences_to_check, start_frame, add_locked=False, add_parented=(not vseqf.children), add_effect=False)
                        #organize by distance
                        update_sequences = sorted(update_sequences, key=lambda x:x.frame_final_start)
                        #cache channels
                        for seq in update_sequences:
                            seq.last_channel = seq.channel
                        for seq in update_sequences:
                            #move sequences
                            if seq.frame_final_start >= end_frame:
                                seq.frame_start = seq.frame_start - offset
                            else:
                                seq.frame_start = seq.frame_start - (seq.frame_final_start - start_frame)
                        for seq in update_sequences:
                            seq.channel = seq.last_channel
                    
                    #Deal with cut sequences
                    for sequence_info in cut_to_sequences:
                        sequence, last_frame_final_start, last_frame_final_duration = sequence_info
                        #fix parent relationships for cut clips
                        if sequence.parent:
                            for parent_info in cut_sequences:
                                if parent_info[0].name == sequence.parent:
                                    #parent of this strip was cut, figure out what it was cut to
                                    for cut_to in cut_to_sequences:
                                        if cut_to[0].channel == parent_info[0].channel:
                                            sequence.parent = cut_to[0].name
                
                    if scene.vseqf.children:
                        for sequence_info in cut_sequences:
                            sequence, last_frame_final_start, last_frame_final_duration = sequence_info
                            #cut child clips if needed
                            original_children = find_children(sequence, sequences=sequences)
                            for child in original_children:
                                if child.frame_final_start < frame_current and child.frame_final_end > frame_current:
                                    #child sequence needs to be cut and new child sequence parented to new sequence
                                    original_selected = bpy.context.selected_sequences
                                    original_active = scene.sequence_editor.active_strip
                                    for seq in sequences:
                                        seq.select = False
                                    
                                    child.select = True
                                    bpy.ops.sequencer.cut(frame=frame_current)
                                    
                                    new_cut_sequences = bpy.context.selected_sequences
                                    
                                    #figure out what 'sequence' was cut to
                                    new_sequence = False
                                    for cut_to in cut_to_sequences:
                                        if cut_to[0].channel == sequence.channel:
                                            new_sequence = cut_to[0]
                                    
                                    if new_sequence:
                                        #the new cut sequence was found, so copy the new child sequences to it
                                        for new_cut_sequence in new_cut_sequences:
                                            if new_cut_sequence != child:
                                                #cut sequence is not the child of the original sequence
                                                add_children(new_sequence, [new_cut_sequence])

                                    for seq in sequences:
                                        seq.select = False
                                    for select in original_selected:
                                        select.select = True
                                    scene.sequence_editor.active_strip = original_active

                    #clear ignored sequences
                    for sequence in ignored_sequences:
                        sequence.ignore_continuous = False
                    
                    #iterate through selected sequences and select child sequences
                    if prefs.parenting and vseqf.select_children:
                        for sequence in bpy.context.selected_sequences:
                            children = find_children(sequence, sequences=sequences)
                            for child in children:
                                if not child.select:
                                    child.select = True
                                    if child.frame_final_start == sequence.frame_final_start:
                                        child.select_left_handle = sequence.select_left_handle
                                    if child.frame_final_end == sequence.frame_final_end:
                                        child.select_right_handle = sequence.select_right_handle


#Functions related to QuickSpeed
@persistent
def frame_step(scene):
    """Handler that skips frames when the speed step value is used
    Argument:
        scene: the current Scene"""
    
    #last_frame = scene.vseqf.last_frame
    #frame = scene.frame_current
    step = scene.vseqf.step
    difference = scene.frame_current - scene.vseqf.last_frame
    if difference < 0:
        step = 0
    if step == 0:
        #no frame skipping
        scene.vseqf.last_frame = scene.frame_current
    if step == 1:
        #if the step is 1, only one frame in every 3 will be skipped
        if difference >= 3:
            scene.frame_current = scene.frame_current + int(difference/3)
            scene.vseqf.last_frame = scene.frame_current
    if step == 2:
        #if the step is 2, every other frame is skipped
        if difference >= 2:
            scene.frame_current = scene.frame_current + int(difference/2)
            scene.vseqf.last_frame = scene.frame_current
    if step > 2:
        #if the step is greater than 2, (step-2) frames will be skipped per frame
        scene.frame_current = scene.frame_current + (step - 2)
        scene.vseqf.last_frame = scene.frame_current

def draw_quickspeed_header(self, context):
    """Draws the speed selector in the sequencer header"""
    layout = self.layout
    scene = context.scene
    self.layout_width = 30
    layout.prop(scene.vseqf, 'step', text="Speed Step")


#Functions and classes related to QuickZoom
def draw_quickzoom_menu(self, context):
    """Draws the submenu for the QuickZoom shortcuts, placed in the sequencer view menu"""
    layout = self.layout
    layout.menu('vseqf.quickzooms_menu', text="Quick Zoom")

def zoom_custom(begin, end):
    """Zooms to an area on the sequencer timeline by adding a temporary strip, zooming to it, then deleting that strip.
    Note that this function will retain selected and active sequences.
    Arguments:
        begin: Integer, the starting frame of the zoom area
        end: Integer, the ending frame of the zoom area"""
    scene = bpy.context.scene
    selected = []
    
    #Find sequence editor, or create if not found
    try:
        sequences = bpy.context.sequences
    except:
        scene.sequence_editor_create()
        sequences = bpy.context.sequences
    
    #Save selected sequences and active strip because they will be overwritten
    for sequence in sequences:
        if (sequence.select):
            selected.append(sequence)
            sequence.select = False
    active = bpy.context.scene.sequence_editor.active_strip
    
    #Determine preroll for the zoom
    zoomlength = end - begin
    if zoomlength > 60:
        preroll = (zoomlength-60) / 10
    else:
        preroll = 0
    
    #Create a temporary sequence, zoom in on it, then delete it
    zoomClip = scene.sequence_editor.sequences.new_effect(name='----vseqf-temp-zoom----', type='ADJUSTMENT', channel=1, frame_start=begin-preroll, frame_end=end)
    zoomClip.ignore_continuous = True
    scene.sequence_editor.active_strip = zoomClip
    for region in bpy.context.area.regions:
        if (region.type == 'WINDOW'):
            override = {'region': region, 'window': bpy.context.window, 'screen': bpy.context.screen, 'area': bpy.context.area, 'scene': bpy.context.scene}
            bpy.ops.sequencer.view_selected(override)
    bpy.ops.sequencer.delete()
    
    #Reset selected sequences and active strip
    for sequence in selected:
        sequence.select = True
    bpy.context.scene.sequence_editor.active_strip = active

def zoom_cursor(self=None, context=None):
    """Zooms near the cursor based on the 'zoom_size' vseqf variable"""
    cursor = bpy.context.scene.frame_current
    zoom_custom(cursor, (cursor + bpy.context.scene.vseqf.zoom_size))

class VSEQFQuickZoomsMenu(bpy.types.Menu):
    """Pop-up menu for sequencer zoom shortcuts"""
    bl_idname = "vseqf.quickzooms_menu"
    bl_label = "Quick Zooms"
    
    def draw(self, context):
        scene = bpy.context.scene
        layout = self.layout
        
        layout.operator('vseqf.quickzooms', text='Zoom All Strips').area = 'all'
        layout.operator('vseqf.quickzooms', text='Zoom To Timeline').area = 'timeline'
        if (len(bpy.context.selected_sequences) > 0):
            #Only show if a sequence is selected
            layout.operator('vseqf.quickzooms', text='Zoom Selected').area = 'selected'
            
        layout.operator('vseqf.quickzooms', text='Zoom Cursor').area = 'cursor'
        layout.prop(scene.vseqf, 'zoom_size', text="Size")
        
        layout.separator()
        layout.operator('vseqf.quickzooms', text='Zoom 2 Seconds').area = '2'
        layout.operator('vseqf.quickzooms', text='Zoom 10 Seconds').area = '10'
        layout.operator('vseqf.quickzooms', text='Zoom 30 Seconds').area = '30'
        layout.operator('vseqf.quickzooms', text='Zoom 1 Minute').area = '60'
        layout.operator('vseqf.quickzooms', text='Zoom 2 Minutes').area = '120'
        layout.operator('vseqf.quickzooms', text='Zoom 5 Minutes').area = '300'
        layout.operator('vseqf.quickzooms', text='Zoom 10 Minutes').area = '600'

class VSEQFQuickZooms(bpy.types.Operator):
    """Wrapper operator for zooming the sequencer in different ways
    Argument:
        area: String, determines the zoom method, can be set to:
            all: calls bpy.ops.sequencer.view_all()
            selected: calls bpy.ops.sequencer.view_selected()
            cursor: calls the zoom_cursor() function
            numerical value: zooms to the number of seconds given in the value"""
    bl_idname = 'vseqf.quickzooms'
    bl_label = 'VSEQF Quick Zooms'
    bl_description = 'Changes zoom level of the sequencer timeline'
    
    #Should be set to 'all', 'selected', cursor', or a positive number of seconds
    area = bpy.props.StringProperty()
    
    def execute(self, context):
        if self.area.isdigit():
            #Zoom value is a number of seconds
            scene = context.scene
            cursor = scene.frame_current
            zoom_custom(cursor, (cursor + ((scene.render.fps/scene.render.fps_base) * int(self.area))))
            
        elif self.area == 'timeline':
            scene = context.scene
            zoom_custom(scene.frame_start, scene.frame_end)
            
        elif self.area == 'all':
            bpy.ops.sequencer.view_all()
            
        elif self.area == 'selected':
            bpy.ops.sequencer.view_selected()
            
        elif self.area == 'cursor':
            zoom_cursor()
            
        return{'FINISHED'}


#Functions and classes related to QuickFades
def crossfade(first_sequence, second_sequence):
    """Add a crossfade between two sequences, the transition type is determined by the vseqf variable 'transition'
    Arguments:
        first_sequence: VSE Sequence object being transitioned from
        second_sequence: VSE Sequence object being transitioned to"""

    type = bpy.context.scene.vseqf.transition
    sequences = bpy.context.scene.sequence_editor.sequences
    channel = first_sequence.channel
    frame_start = first_sequence.frame_final_end
    frame_end = second_sequence.frame_final_start
    overlapping = overlap_sequences(sequences=sequences, frame_start=frame_start, frame_end=frame_end)
    channel_clear = False
    while not channel_clear:
        channel_clear = True
        for sequence in overlapping:
            if sequence.channel == channel:
                channel = channel + 1
                channel_clear = False

    fade = sequences.new_effect(name=type, type=type, channel=channel,  frame_start=frame_start, frame_end=frame_end, seq1=first_sequence, seq2=second_sequence)
    fade.ignore_continuous = True

def fades(sequence, mode, type, fade_length=0, fade_low_point_frame=False):
    """Detects, creates, and edits fadein and fadeout for sequences.
    Arguments:
        sequence: VSE Sequence object that will be operated on
        mode: String, determines the operation that will be done
            detect: determines the fade length set to the sequence
            set: sets a desired fade length to the sequence
            clear: removes all fades from the sequence
        type: String, determines if the function works with fadein or fadeout
            in: fadein is operated on
            out: fadeout is operated on
        fade_length: Integer, optional value used only when setting fade lengths
        fade_low_point_frame: Integer, optional value used for detecting a fade at a point other than at the edge of the sequence"""
    scene = bpy.context.scene
    
    #These functions check for the needed variables and create them if in set mode.  Otherwise, ends the function.
    if scene.animation_data == None:
        #No animation data in scene, create it
        if (mode == 'set'):
            scene.animation_data_create()
        else:
            return 0
    if scene.animation_data.action == None:
        #No action in scene, create it
        if mode == 'set':
            action = bpy.data.actions.new(scene.name+"Action")
            scene.animation_data.action = action
        else:
            return 0
    
    all_curves = scene.animation_data.action.fcurves
    fade_curve = False #curve for the fades
    fade_low_point = False #keyframe that the fade reaches minimum value at
    fade_high_point = False #keyframe that the fade starts maximum value at
    if (type == 'in'):
        if not fade_low_point_frame:
            fade_low_point_frame = sequence.frame_final_start
    else:
        if not fade_low_point_frame:
            fade_low_point_frame = sequence.frame_final_end
        fade_length = -fade_length
    fade_high_point_frame = fade_low_point_frame + fade_length
    
    fade_max_value = 1 #set default fade max value, this may change
    
    #set up the data value to fade
    if sequence.type == 'SOUND':
        fade_variable = 'volume'
    else:
        fade_variable = 'blend_alpha'

    #attempts to find the fade keyframes by iterating through all curves in scene
    for curve in all_curves:
        if (curve.data_path == 'sequence_editor.sequences_all["'+sequence.name+'"].'+fade_variable):
            #keyframes found
            fade_curve = curve
            
            #delete keyframes and end function
            if mode == 'clear':
                all_curves.remove(fade_curve)
                return 0
            
    if not fade_curve:
        #no fade animation curve found, create and continue if instructed to, otherwise end function
        if (mode == 'set'):
            fade_curve = all_curves.new(data_path=sequence.path_from_id(fade_variable))
            keyframes = fade_curve.keyframe_points
        else:
            return 0
    
    #Detect fades or add if set mode
    fade_keyframes = fade_curve.keyframe_points
    if len(fade_keyframes) == 0:
        #no keyframes found, create them if instructed to do so
        if (mode == 'set'):
            fade_max_value = getattr(sequence, fade_variable)
            set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value)
        else:
            return 0
            
    elif len(fade_keyframes) == 1:
        #only one keyframe, use y value of keyframe as the max value for a new fade
        if (mode == 'set'):
            #determine fade_max_value from value at one keyframe
            fade_max_value = fade_keyframes[0].co[1]
            if fade_max_value == 0:
                fade_max_value = 1
            
            #remove lone keyframe, then add new fade
            fade_keyframes.remove(fade_keyframes[0])
            set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value)
        else:
            return 0
    
    elif len(fade_keyframes) > 1:
        #at least 2 keyframes, there may be a fade already
        if type == 'in':
            fade_low_point = fade_keyframes[0]
            fade_high_point = fade_keyframes[1]
        elif type == 'out':
            fade_low_point = fade_keyframes[-1]
            fade_high_point = fade_keyframes[-2]
        
        #check to see if the fade points are valid
        if fade_low_point.co[1] == 0:
            #opacity is 0, assume there is a fade
            if fade_low_point.co[0] == fade_low_point_frame:
                #fade low point is in the correct location
                if fade_high_point.co[1] > fade_low_point.co[1]:
                    #both fade points are valid
                    if mode == 'set':
                        fade_max_value = fade_high_point.co[1]
                        set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value, fade_low_point=fade_low_point, fade_high_point=fade_high_point)
                        return fade_length
                    else:
                        #fade detected!
                        return abs(fade_high_point.co[0] - fade_low_point.co[0])
                else:
                    #fade high point is not valid, low point is tho
                    if mode == 'set':
                        fade_max_value = fade_curve.evaluate(fade_high_point_frame)
                        set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value, fade_low_point=fade_low_point)
                        return fade_length
                    else:
                        return 0
            else:
                #fade low point is not in the correct location
                if mode == 'set':
                    #check fade high point
                    if fade_high_point.co[1] > fade_low_point.co[1]:
                        #fade exists, but is not set up properly
                        fade_max_value = fade_high_point.co[1]
                        set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value, fade_low_point=fade_low_point, fade_high_point=fade_high_point)
                        return fade_length
                    else:
                        #no valid fade high point
                        fade_max_value = fade_curve.evaluate(fade_high_point_frame)
                        set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value, fade_low_point=fade_low_point)
                        return fade_length
                else:
                    return 0
            
        else:
            #no valid fade detected, other keyframes are on the curve tho
            if mode == 'set':
                fade_max_value = fade_curve.evaluate(fade_high_point_frame)
                set_fade(fade_keyframes, type, fade_low_point_frame, fade_high_point_frame, fade_max_value)
                return fade_length
            else:
                return 0

def set_fade(fade_keyframes, direction, fade_low_point_frame, fade_high_point_frame, fade_max_value, fade_low_point = None, fade_high_point = None):
    """Create or change a fadein or fadeout on  a set of keyframes
    Arguments:
        fade_keyframes: keyframe curve to operate on
        direction: String, determines if a fadein or fadeout will be set
            'in': Set a fadein
            'out': Set a fadeout
        fade_low_point_frame: Integer, the frame at which the fade should be at its lowest value
        fade_high_point_frame: Integer, the frame at which the fade should be at its highest value
        fade_max_value: Float, the y value for the high point of the fade
        fade_low_point: Optional, a keyframe point for the low point of the fade curve that should be moved, instead of creating a new one
        fade_high_point: Optional, a keyframe point for the high point of the fade curve that should be moved, instead of creating a new one"""

    #check if any keyframe points other than the fade high and low points are in the fade area, delete them if needed
    for keyframe in fade_keyframes:
        if direction == 'in':
            if (keyframe.co[0] < fade_high_point_frame) and (keyframe.co[0] > fade_low_point_frame):
                if (keyframe != fade_low_point) and (keyframe != fade_high_point):
                    fade_keyframes.remove(keyframe)
        if direction == 'out':
            if (keyframe.co[0] > fade_high_point_frame) and (keyframe.co[0] < fade_low_point_frame):
                if (keyframe != fade_low_point) and (keyframe != fade_high_point):
                    fade_keyframes.remove(keyframe)

    fade_length = abs(fade_high_point_frame - fade_low_point_frame)
    handle_offset = fade_length * .38
    if fade_low_point:
        if fade_length != 0:
            #move fade low point to where it should be
            fade_low_point.co = ((fade_low_point_frame, 0))
            fade_low_point.handle_left = ((fade_low_point_frame - handle_offset, 0))
            fade_low_point.handle_right = ((fade_low_point_frame + handle_offset, 0))
        else:
            #remove fade low point
            fade_keyframes.remove(fade_low_point)
    else:
        if fade_high_point_frame != fade_low_point_frame:
            #create new fade low point
            fade_keyframes.insert(frame=fade_low_point_frame, value=0)
        
    if fade_high_point:
        #move fade high point to where it should be
        fade_high_point.co = ((fade_high_point_frame, fade_max_value))
        fade_high_point.handle_left = ((fade_high_point_frame - handle_offset, fade_max_value))
        fade_high_point.handle_right = ((fade_high_point_frame + handle_offset, fade_max_value))
    else:
        #create new fade high point
        fade_keyframes.insert(frame=fade_high_point_frame, value=fade_max_value)

class VSEQFQuickFadesPanel(bpy.types.Panel):
    """Panel for QuickFades operators and properties.  Placed in the VSE properties area."""
    bl_label = "Quick Fades"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
        
    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        try:
            #Check for an active sequence to operate on
            sequence = context.scene.sequence_editor.active_strip
            if (sequence):
                return prefs.fades
            else:
                return False
                
        except:
            return False
    
    def draw(self, context):
        #Set up basic variables needed by panel
        scene = bpy.context.scene
        vseqf = scene.vseqf
        active_sequence = scene.sequence_editor.active_strip
        frame = scene.frame_current
        fadein = fades(sequence=active_sequence, mode='detect', type='in')
        fadeout = fades(sequence=active_sequence, mode='detect', type='out')
        
        layout = self.layout
        
        #First row, detected fades
        row = layout.row()
        if fadein > 0:
            row.label("Fadein: "+str(round(fadein))+" Frames")
        else:
            row.label("No Fadein Detected")
        if fadeout > 0:
            row.label("Fadeout: "+str(round(fadeout))+" Frames")
        else:
            row.label("No Fadeout Detected")
        
        #Setting fades section
        row = layout.row()
        row.prop(vseqf, 'fade')
        row = layout.row(align=True)
        row.operator('vseqf.quickfades_set', text='Set Fadein', icon='BACK').type = 'in'
        row.operator('vseqf.quickfades_set', text='Set In/Out').type = 'both'
        row.operator('vseqf.quickfades_set', text='Set Fadeout', icon='FORWARD').type = 'out'
        row = layout.row()
        row.operator('vseqf.quickfades_clear', text='Clear Fades')
        row = layout.row()
        row.separator()
        
        #Crossfades section
        row = layout.row()
        row.prop(vseqf, 'transition')
        row = layout.row(align=True)
        row.operator('vseqf.quickfades_cross', text='Crossfade Prev Clip', icon='BACK').type = 'previous'
        row.operator('vseqf.quickfades_cross', text='Crossfade Next Clip', icon='FORWARD').type = 'next'
        row = layout.row(align=True)
        row.operator('vseqf.quickfades_cross', text='Smart Cross to Prev', icon='BACK').type = 'previoussmart'
        row.operator('vseqf.quickfades_cross', text='Smart Cross to Next', icon='FORWARD').type = 'nextsmart'

class VSEQFQuickFadesMenu(bpy.types.Menu):
    """Pop-up menu for QuickFade operators"""
    bl_idname = "vseqf.quickfades_menu"
    bl_label = "Quick Fades"
    
    @classmethod
    def poll(self, context):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        return prefs.fades

    def draw(self, context):
        scene = bpy.context.scene
        sequences = bpy.context.selected_sequences
        sequence = scene.sequence_editor.active_strip
        
        layout = self.layout
        if sequence and len(sequences) > 0:
            #If a sequence is active
            frame = scene.frame_current
            vseqf = scene.vseqf
            fadein = fades(sequence=sequence, mode='detect', type='in')
            fadeout = fades(sequence=sequence, mode='detect', type='out')
            
            #Detected fades section
            if fadein > 0:
                layout.label("Fadein: "+str(round(fadein))+" Frames")
            else:
                layout.label("No Fadein Detected")
            if fadeout > 0:
                layout.label("Fadeout: "+str(round(fadeout))+" Frames")
            else:
                layout.label("No Fadeout Detected")
                        
            #Fade length
            layout.prop(vseqf, 'fade')
            layout.operator('vseqf.quickfades_set', text='Set Fadein').type = 'in'
            layout.operator('vseqf.quickfades_set', text='Set Fadeout').type = 'out'
            layout.operator('vseqf.quickfades_clear', text='Clear Fades')
            
            #Add crossfades
            layout.separator()
            layout.prop(vseqf, 'transition', text='')
            layout.operator('vseqf.quickfades_cross', text='Crossfade Prev Sequence').type = 'previous'
            layout.operator('vseqf.quickfades_cross', text='Crossfade Next Sequence').type = 'next'
            layout.operator('vseqf.quickfades_cross', text='Smart Cross to Prev').type = 'previoussmart'
            layout.operator('vseqf.quickfades_cross', text='Smart Cross to Next').type = 'nextsmart'
        
        else:
            layout.label("No Sequence Selected")

class VSEQFQuickFadesSet(bpy.types.Operator):
    """Operator to add fades to selected sequences
    Uses the vseqf fade_length variable for length
    Argument:
        type: String, determines if a fadein or fadeout should be set
            'in': sets a fadein
            'out': sets a fadeout
            'both': sets fadein and fadeout"""

    bl_idname = 'vseqf.quickfades_set'
    bl_label = 'VSEQF Quick Fades Set Fade'
    bl_description = 'Adds or changes fade for selected sequences'
    
    #Should be set to 'in' or 'out'
    type = bpy.props.StringProperty()
    
    def execute(self, context):
        #iterate through selected sequences and apply fades to them
        for sequence in context.selected_sequences:
            if self.type == 'both':
                fades(sequence=sequence, mode='set', type='in', fade_length=context.scene.vseqf.fade)
                fades(sequence=sequence, mode='set', type='out', fade_length=context.scene.vseqf.fade)
            else:
                fades(sequence=sequence, mode='set', type=self.type, fade_length=context.scene.vseqf.fade)
        
        return{'FINISHED'}

class VSEQFQuickFadesClear(bpy.types.Operator):
    """Operator to clear fades on selected sequences"""
    bl_idname = 'vseqf.quickfades_clear'
    bl_label = 'VSEQF Quick Fades Clear Fades'
    bl_description = 'Clears fade in and out for selected sequences'
    
    def execute(self, context):
        for sequence in bpy.context.selected_sequences:
            #iterate through selected sequences, remove fades, and set opacity to full
            fades(sequence=sequence, mode='clear', type='both', fade_length=bpy.context.scene.vseqf.fade)
            sequence.blend_alpha = 1
            
        return{'FINISHED'}

class VSEQFQuickFadesCross(bpy.types.Operator):
    """Operator to add crossfades from selected sequences
    This operator will maintain selected and active sequences
    
    Argument:
        type: String, determines how a fade should be added
            'next': detects the next sequence and adds a simple fade
            'previous': detects the previous sequence and adds a simple fade
            'nextsmart': detects the next sequence, adjusts the edges to create a fade of the length set in the vseqf variable 'fade', then adds the crossfade
            'previoussmart': same as nextsmart, but detects the previous sequence"""

    bl_idname = 'vseqf.quickfades_cross'
    bl_label = 'VSEQF Quick Fades Add Crossfade'
    bl_description = 'Adds a crossfade between selected sequence and next or previous sequence in timeline'
    
    type = bpy.props.StringProperty()
    
    def execute(self, context):
        sequences = bpy.context.sequences
        
        #store a list of selected sequences since adding a crossfade destroys the selection
        selected_sequences = bpy.context.selected_sequences
        active_sequence = bpy.context.scene.sequence_editor.active_strip
        
        for sequence in selected_sequences:
            if sequence.type != 'SOUND' and not hasattr(sequence, 'input_1'):
                #iterate through selected sequences and add crossfades to previous or next sequence
                if self.type == 'nextsmart':
                    #Need to find next sequence
                    first_sequence = sequence
                    second_sequence = find_close_sequence(sequences, first_sequence, 'next', mode='all')
                    
                elif self.type == 'previoussmart':
                    #Need to find previous sequence
                    second_sequence = sequence
                    first_sequence = find_close_sequence(sequences, second_sequence, 'prev', mode='all')
                    
                elif self.type == 'next':
                    #Need to find next sequence
                    first_sequence = sequence
                    second_sequence = find_close_sequence(sequences, first_sequence, 'next', mode='all')
                    
                elif self.type == 'previous':
                    #Need to find previous sequence
                    second_sequence = sequence
                    first_sequence = find_close_sequence(sequences, second_sequence, 'prev', mode='all')

                if (second_sequence != False) & (first_sequence != False):
                    if 'smart' in self.type:
                        first_sequence.ignore_continuous = True
                        second_sequence.ignore_continuous = True
                        #adjust start and end frames of sequences based on frame_offset_end/start to overlap by amount of crossfade
                        target_fade = bpy.context.scene.vseqf.fade
                        current_fade = first_sequence.frame_final_end - second_sequence.frame_final_start
                        
                        #if current_fade is negative, there is open space between clips, if positive, clips are overlapping
                        if current_fade <= 0:
                            fade_offset = abs(current_fade + target_fade)
                            first_sequence_offset = -round((fade_offset/2)+.1)
                            second_sequence_offset = -round((fade_offset/2)-.1)
                        else:
                            fade_offset = abs(current_fade - target_fade)
                            first_sequence_offset = round((fade_offset/2)+.1)
                            second_sequence_offset = round((fade_offset/2)-.1)
                        
                        if abs(current_fade) < target_fade:
                            #detected overlap is not enough, extend the ends of the sequences to match the target overlap
                            
                            if ((first_sequence.frame_offset_end > first_sequence_offset) & (second_sequence.frame_offset_start > second_sequence_offset)) | ((first_sequence.frame_offset_end == 0) & (first_sequence.frame_offset_start == 0)):
                                #both sequence offsets are larger than both target offsets or neither sequence has offsets
                                first_sequence.frame_final_end = first_sequence.frame_final_end + first_sequence_offset
                                second_sequence.frame_final_start = second_sequence.frame_final_start - second_sequence_offset
                                
                            else:
                                #sequence offsets need to be adjusted individually
                                currentOffset = first_sequence.frame_offset_end + second_sequence.frame_offset_start
                                first_sequence_offset_percent = first_sequence.frame_offset_end / currentOffset
                                second_sequence_offset_percent = second_sequence.frame_offset_start / currentOffset
                                first_sequence.frame_final_end = first_sequence.frame_final_end + (round(first_sequence_offset_percent * fade_offset))
                                second_sequence.frame_final_start = second_sequence.frame_final_start - (round(second_sequence_offset_percent * fade_offset))
                        
                        elif abs(current_fade) > target_fade:
                            #detected overlap is larger than target fade, subtract equal amounts from each sequence
                            first_sequence.frame_final_end = first_sequence.frame_final_end - first_sequence_offset
                            second_sequence.frame_final_start = second_sequence.frame_final_start + second_sequence_offset
                    fade_exists = find_crossfade(sequences, first_sequence, second_sequence)
                    if not fade_exists:
                        crossfade(first_sequence, second_sequence)
                    
                else:
                    self.report({'WARNING'}, 'No Second Sequence Found')
        
        bpy.ops.sequencer.select_all(action='DESELECT')
        for sequence in selected_sequences:
            sequence.select = True
        bpy.context.scene.sequence_editor.active_strip = active_sequence
        bpy.ops.ed.undo_push()
        return{'FINISHED'}


#Functions and classes related to QuickParents
def find_sound_child(parent_sequence, sequences):
    """Looks for a sound sequence that is related to a video sequence
    Arguments:
        parent_sequence: VSE Sequence object who's sound file will be searched for
        sequences: List of sequences to search
        
    Returns: Boolean False if nothing found, VSE Sequence object if match found"""

    for sequence in sequences:
        if ((os.path.splitext(sequence.name)[0] == os.path.splitext(parent_sequence.name)[0]) & (sequence.type == 'SOUND')):
            return sequence
    return False

def add_children(parent_sequence, child_sequences):
    """Adds parent-child relationships to sequences
    Arguments:
        parent_sequence: VSE Sequence to set as the parent
        child_sequences: List of VSE Sequence objects to set as children"""

    for child_sequence in child_sequences:
        if (child_sequence.name != parent_sequence.name):
            child_sequence.parent = parent_sequence.name

def find_children(parent_sequence, name=False, sequences=False):
    """Gets a list of sequences that are children of a sequence
    Arguments:
        parent_sequence: VSE Sequence object or String name of a sequence to search for children of
        name: Boolean, if True, the passed-in 'parent_sequence' is a name of the parent, if False, the passed in 'parent_sequence' is the actual sequence object
        sequences: Optional, a list of sequences may be passed in here, they will be the only ones searched
    
    Returns: List of VSE Sequence objects, or empty list if none found"""
    
    if name:
        parent_name = parent_sequence
    else:
        parent_name = parent_sequence.name
    if not sequences:
        sequences = bpy.context.scene.sequence_editor.sequences_all
    child_sequences = []
    for sequence in sequences:
        if sequence.parent == parent_name:
            child_sequences.append(sequence)
    return child_sequences

def find_parent(child_sequence):
    """Gets the parent sequence of a child sequence
    Argument:
        child_sequence: VSE Sequence object to search for the parent of
    
    Returns: VSE Sequence object if match found, Boolean False if no match found"""
    scene = bpy.context.scene
    sequences = scene.sequence_editor.sequences_all
    if child_sequence.parent in sequences:
        return sequences[child_sequence.parent]
    else:
        return False

def clear_children(parent_sequence):
    """Removes all child relationships from a parent sequence
    Argument:
        parent_sequence: VSE Sequence object to search for children of"""
    scene = bpy.context.scene
    sequences = scene.sequence_editor.sequences_all
    for sequence in sequences:
        if sequence.parent == parent_sequence.name:
            clear_parent(sequence)

def clear_parent(child_sequence):
    """Removes the parent relationship of a child sequence
    Argument:
        child_sequence: VSE Sequence object to remove the parent relationship of"""
    child_sequence.parent = ''

def select_children(parent_sequence, sequences=False):
    """Selects all children of a given sequence
    Arguments:
        parent_sequence: VSE Sequence to search for children of
        sequences: Optional, list of sequences to search through"""
        
    children = find_children(parent_sequence, sequences=sequences)
    for child in children:
        child.select = True

def select_parent(child_sequence):
    """Selects the parent of a sequence
    Argument:
        child_sequence: VSE Sequence object to find the parent of"""
        
    parent = find_parent(child_sequence)
    if parent:
        parent.select = True

class VSEQFQuickParentsMenu(bpy.types.Menu):
    """Pop-up menu for QuickParents, displays parenting operators, and relationships"""
    bl_idname = "vseqf.quickparents_menu"
    bl_label = "Quick Parents"
    
    @classmethod
    def poll(self, context):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        return prefs.parenting

    def draw(self, context):
        scene = bpy.context.scene
        sequence = scene.sequence_editor.active_strip
        layout = self.layout
        
        if sequence:
            #Active sequence set
            if len(scene.sequence_editor.meta_stack) > 0:
                #inside a meta strip
                sequencer = scene.sequence_editor.meta_stack[-1]
            else:
                #not inside a meta strip
                sequencer = scene.sequence_editor
            if hasattr(sequencer, 'sequences'):
                sequences = sequencer.sequences
            else:
                sequences = []

            selected = bpy.context.selected_sequences
            children = find_children(sequence, sequences=sequences)
            parent = find_parent(sequence)
            
            layout.operator('vseqf.quickparents', text='Select Children').action = 'select_children'
            layout.operator('vseqf.quickparents', text='Select Parent').action = 'select_parent'
            if len(selected) > 1:
                #more than one sequence is selected, so children can be set
                layout.operator('vseqf.quickparents', text='Set Active As Parent').action = 'add'
                
            layout.operator('vseqf.quickparents', text='Clear Children').action = 'clear_children'
            layout.operator('vseqf.quickparents', text='Clear Parent').action = 'clear_parent'
            
            if parent:
                #Parent sequence is found, display it
                layout.separator()
                layout.label("     Parent: ")
                layout.label(parent.name)
                layout.separator()
                
            if len(children) > 0:
                #At least one child sequence is found, display them
                layout.separator()
                layout.label("     Children:")
                index = 0
                while index < len(children):
                    layout.label(children[index].name)
                    index = index + 1
                layout.separator()
                
        else:
            layout.label('No Sequence Selected')

class VSEQFQuickParents(bpy.types.Operator):
    """Changes parenting relationships on selected sequences
    
    Argument:
        action: String, determines what this operator will attempt to do
            'add': Adds selected sequences as children of the active sequence
            'select_children': Selects children of all selected sequences
            'select_parent': Selects parents of all selected sequences
            'clear_parent': Clears parent relationships of all selected sequences
            'clear_children': Clears all child relationships of all selected sequences"""
            
    bl_idname = 'vseqf.quickparents'
    bl_label = 'VSEQF Quick Parents'
    bl_description = 'Sets Or Removes Strip Parents'
    
    action = bpy.props.StringProperty()
    
    def execute(self, context):
        scene = bpy.context.scene
        selected = bpy.context.selected_sequences
        active = scene.sequence_editor.active_strip
        
        if (self.action == 'add') and (len(selected) > 1):
            add_children(active, selected)
        else:
            if len(scene.sequence_editor.meta_stack) > 0:
                #inside a meta strip
                sequencer = scene.sequence_editor.meta_stack[-1]
            else:
                #not inside a meta strip
                sequencer = scene.sequence_editor
            if hasattr(sequencer, 'sequences'):
                sequences = sequencer.sequences
            else:
                sequences = []
            for sequence in selected:
                if self.action == 'select_children':
                    select_children(sequence, sequences=sequences)
                if self.action == 'select_parent':
                    select_parent(sequence)
                if self.action == 'clear_parent':
                    clear_parent(sequence)
                if self.action == 'clear_children':
                    clear_children(sequence)
        return {'FINISHED'}

class VSEQFQuickParentsClear(bpy.types.Operator):
    """Clears the parent of a sequence
    Argument:
        strip: String, the name of the sequence to clear the parent of"""

    bl_idname = 'vseqf.quickparents_clear_parent'
    bl_label = 'VSEQF Quick Parent Remove Parent'
    bl_description = 'Removes Strip Parent'

    strip = bpy.props.StringProperty()
    
    def execute(self, context):
        sequences = context.sequences
        for sequence in sequences:
            if sequence.name == self.strip:
                clear_parent(sequence)
                break
        return {'FINISHED'}


#Functions and classes related to QuickSnaps
def draw_quicksnap_menu(self, context):
    """Draws the QuickSnaps pop-up menu"""
    layout = self.layout
    layout.menu('vseqf.quicksnaps_menu', text="Quick Snaps")

class VSEQFQuickSnapsMenu(bpy.types.Menu):
    """QuickSnaps pop-up menu listing snapping operators"""
    bl_idname = "vseqf.quicksnaps_menu"
    bl_label = "Quick Snaps"
    
    def draw(self, context):
        layout = self.layout
        layout.operator('vseqf.quicksnaps', text='Cursor To Nearest Second').type = 'cursor_to_seconds'
        scene = bpy.context.scene
        
        try:
            #Display only if active sequence is set
            sequence = scene.sequence_editor.active_strip
            if (sequence):
                layout.operator('vseqf.quicksnaps', text='Cursor To Beginning Of Sequence').type = 'cursor_to_beginning'
                layout.operator('vseqf.quicksnaps', text='Cursor To End Of Sequence').type = 'cursor_to_end'
                layout.separator()
                layout.operator('vseqf.quicksnaps', text='Selected To Cursor').type = 'selected_to_cursor'
                layout.operator('vseqf.quicksnaps', text='Sequence Beginning To Cursor').type = 'begin_to_cursor'
                layout.operator('vseqf.quicksnaps', text='Sequence End To Cursor').type = 'end_to_cursor'
                layout.operator('vseqf.quicksnaps', text='Sequence To Previous Sequence').type = 'sequence_to_previous'
                layout.operator('vseqf.quicksnaps', text='Sequence To Next Sequence').type = 'sequence_to_next'
        
        except:
            pass

class VSEQFQuickSnaps(bpy.types.Operator):
    """Operator for snapping the cursor and sequences
    Argument:
        type: String, snapping operation to perform
            'cursor_to_seconds': Rounds the cursor position to the nearest second
            'cursor_to_beginning': Moves the cursor to the beginning of the active sequence
            'cursor_to_end': Moves the cursor to the end of the active sequence
            'selected_to_cursor': Moves the beginning of selected sequences to the cursor position, using bpy.ops.sequencer.snap()
            'begin_to_cursor': Moves the beginning of selected sequences to the cursor position
            'end_to_cursor': Moves the ending of selected sequences to the cursor position
            'sequence_to_previous': Snaps the active sequence to the closest previous sequence
            'sequence_to_next': Snaps the active sequence to the closest next sequence"""

    bl_idname = 'vseqf.quicksnaps'
    bl_label = 'VSEQF Quick Snaps'
    bl_description = 'Snaps selected sequences'
    
    type = bpy.props.StringProperty()
    
    def execute(self, context):
        #Set up variables needed for operator
        selected = bpy.context.selected_sequences
        scene = bpy.context.scene
        active = bpy.context.scene.sequence_editor.active_strip
        frame = scene.frame_current
        
        #Cursor snaps
        if self.type == 'cursor_to_seconds':
            fps = scene.render.fps / scene.render.fps_base
            scene.frame_current = round(round(scene.frame_current / fps) * fps)
        
        if self.type == 'cursor_to_beginning':
            scene.frame_current = active.frame_final_start
        
        if self.type == 'cursor_to_end':
            scene.frame_current = active.frame_final_end
        
        if self.type == 'selected_to_cursor':
            bpy.ops.sequencer.snap(frame=frame)
        
        #Sequence snaps
        if self.type == 'begin_to_cursor':
            for sequence in selected:
                offset = sequence.frame_final_start - sequence.frame_start
                sequence.frame_start = (frame - offset)
        
        if self.type == 'end_to_cursor':
            for sequence in selected:
                offset = sequence.frame_final_start - sequence.frame_start
                sequence.frame_start = (frame - offset - sequence.frame_final_duration)
        
        if self.type == 'sequence_to_previous':
            previous = find_close_sequence(scene.sequence_editor.sequences, active, 'previous', 'any')
            
            if previous:
                for sequence in selected:
                    offset = sequence.frame_final_start - sequence.frame_start
                    sequence.frame_start = (previous.frame_final_end - offset)
            
            else:
                self.report({'WARNING'}, 'No Previous Sequence Found')
        
        if self.type == 'sequence_to_next':
            next = find_close_sequence(scene.sequence_editor.sequences, active, 'next', 'any')
            
            if (next):
                for sequence in selected:
                    offset = sequence.frame_final_start - sequence.frame_start
                    sequence.frame_start = (next.frame_final_start - offset - sequence.frame_final_duration)
            
            else:
                self.report({'WARNING'}, 'No Next Sequence Found')
        
        return{'FINISHED'}


#Functions and classes related to QuickList
def quicklist_sorted_strips(sequences=False, sortmode=False):
    """Gets a list of current VSE Sequences sorted by the vseqf 'quicklist_sort' mode
    Arguments:
        sequences: Optional, list of sequences to sort
        sortmode: Optional, overrides the sort method, can be set to any of the sort methods in the vseqf setting 'quicklist_sort'
        
    Returns: List of VSE Sequence objects"""
    
    if not sequences:
        sequences = list(bpy.context.sequences)
    if not sortmode:
        sortmode = bpy.context.scene.vseqf.quicklist_sort
    reverse = bpy.context.scene.vseqf.quicklist_sort_reverse
    
    #sort the sequences
    if (sortmode == 'TITLE'):
        sequences.sort(key=lambda sequence: sequence.name)
        if sequences and reverse:
            sequences.reverse()
    elif (sortmode == 'LENGTH'):
        sequences.sort(key=lambda sequence: sequence.frame_final_duration)
        if sequences and not reverse:
            sequences.reverse()
    else:
        sequences.sort(key=lambda sequence: sequence.frame_final_start)
        if sequences and reverse:
            sequences.reverse()

    #Check for effect sequences and move them next to their parent sequence
    for sequence in sequences:
        if hasattr(sequence, 'input_1'):
            resort = sequences.pop(sequences.index(sequence))
            parentindex = sequences.index(sequence.input_1)
            sequences.insert(parentindex + 1, resort)

    return sequences

def swap_sequence(first, second):
    """Swaps two sequences in the VSE, attempts to maintain channels.
    Arguments:
        first: First sequence, must be the one to the left
        second: Second sequence, must be the one to the right"""
    
    first_channel = first.channel
    second_channel = second.channel
    second_offset = second.frame_final_start - first.frame_final_start
    first_offset = second.frame_final_end - first.frame_final_duration - 1
    first.frame_start = first.frame_start + first_offset
    second.frame_start = second.frame_start - second_offset
    first_start = first.frame_start
    second_start = second.frame_start
    first.channel = second_channel
    second.channel = first_channel
    first.frame_start = first_start
    second.frame_start = second_start

class VSEQFQuickListPanel(bpy.types.Panel):
    """Panel for displaying QuickList"""
    bl_label = "Quick List"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Quick List"
    
    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        #Check for sequences
        if not bpy.context.sequences:
            return False
        if len(bpy.context.sequences) > 0:
            return prefs.list
        else:
            return False
    
    def draw(self, contex):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        scene = bpy.context.scene
        sequencer = scene.sequence_editor
        sequences = bpy.context.sequences
        active = sequencer.active_strip
        vseqf = scene.vseqf
        
        #Sort the sequences
        sorted = quicklist_sorted_strips()
        
        layout = self.layout
        
        #Display Mode
        row = layout.row(align=True)
        row.label('Display:')
        row.prop(vseqf, 'quicklist_editing', toggle=True)
        if prefs.parenting:
            row.prop(vseqf, 'quicklist_parenting', toggle=True)
        if prefs.tags:
            row.prop(vseqf, 'quicklist_tags', toggle=True)
        
        #Select all and sort buttons
        row = layout.row()
        row.operator('vseqf.quicklist_select', text='Select/Deselect All Sequences').sequence = ''
        row = layout.row(align=True)
        row.label('Sort By:')
        row.prop(vseqf, 'quicklist_sort', expand=True)
        if vseqf.quicklist_sort_reverse:
            reverse_icon = 'TRIA_UP'
        else:
            reverse_icon = 'TRIA_DOWN'
        row.prop(vseqf, 'quicklist_sort_reverse', text='', icon=reverse_icon, toggle=True)
        
        #Display all sequences
        for index, sequence in enumerate(sorted):
            if vseqf.quicklist_sort == 'POSITION':
                column = layout.split(percentage=0.93, align=True)
            else:
                column = layout
            if hasattr(sequence, 'input_1'):
                #Effect sequence, add an indent
                row = box.row()
                row.separator()
                row.separator()
                outline = row.box()
            else:
                outline = column.box()
            box = outline.column()
            
            #First row - mute, lock, type and title
            if sequence == active:
                subbox = box.box()
                row = subbox.row(align=True)
            else:
                row = box.row(align=True)
            split = row.split(align=True)
            split.prop(sequence, 'mute', text='')
            split.prop(sequence, 'lock', text='')
            split = row.split(align=True, percentage=0.2)
            col = split.column(align=True)
            col.operator('vseqf.quicklist_select', text="("+sequence.type+")").sequence = sequence.name
            col.active = sequence.select
            col = split.column(align=True)
            col.prop(sequence, 'name', text='')
            
            #Second row - length and position in time index
            row = box.row()
            split = row.split(percentage=0.8)
            col = split.row()
            col.label("Len: "+timecode_from_frames(sequence.frame_final_duration, (scene.render.fps / scene.render.fps_base), levels=4))
            col.label("Pos: "+timecode_from_frames(sequence.frame_start, (scene.render.fps / scene.render.fps_base), levels=4))

            #Third row - length, position and proxy toggle
            if vseqf.quicklist_editing:
                subbox = box.box()
                row = subbox.row()
                split = row.split(percentage=0.8)
                col = split.row(align=True)
                col.prop(sequence, 'frame_final_duration', text="Len")
                col.prop(sequence, 'frame_start', text="Pos")
                col = split.row()
                if (sequence.type != 'SOUND') and (sequence.type != 'MOVIECLIP') and (not hasattr(sequence, 'input_1')):
                    col.prop(sequence, 'use_proxy', text='Proxy', toggle=True)
                    if (sequence.use_proxy):
                        #Proxy is enabled, add row for proxy settings
                        row = subbox.row()
                        split = row.split(percentage=0.33)
                        col = split.row(align=True)
                        col.prop(sequence.proxy, 'quality')
                        col = split.row(align=True)
                        col.prop(sequence.proxy, 'build_25', toggle=True)
                        col.prop(sequence.proxy, 'build_50', toggle=True)
                        col.prop(sequence.proxy, 'build_75', toggle=True)
                        col.prop(sequence.proxy, 'build_100', toggle=True)
            
            #list tags if there are any
            if prefs.tags and len(sequence.tags) > 0 and vseqf.quicklist_tags:
                line = 1
                linemax = 4
                subbox = box.box()
                row = subbox.row()
                row.label('Tags:')
                for tag in sequence.tags:
                    if line > linemax:
                        row = subbox.row()
                        row.label('')
                        line = 1
                    split = row.split(percentage=.8, align=True)
                    split.operator('vseqf.quicktags_select', text=tag.text).text = tag.text
                    split.operator('vseqf.quicktags_remove_from', text='', icon='X').tag = tag.text+'\n'+sequence.name
                    line = line + 1
            
            #List children sequences if found
            children = find_children(sequence, sequences=sequences)
            if len(children) > 0 and vseqf.quicklist_parenting and prefs.parenting:
                subbox = box.box()
                row = subbox.row()
                split = row.split(percentage=0.25)
                col = split.column()
                col.label('Children:')
                col = split.column()
                for child in children:
                    subsplit = col.split(percentage=0.85)
                    subsplit.label(child.name)
                    subsplit.operator('vseqf.quickparents_clear_parent', text="", icon='X').strip = child.name
            
            #List sub-sequences in a meta sequence
            if sequence.type == 'META':
                row = box.row()
                split = row.split(percentage=0.25)
                col = split.column()
                col.label('Sub-sequences:')
                col = split.column()
                for index, subsequence in enumerate(sequence.sequences):
                    if index > 6:
                        #Stops listing sub-sequences if list is too long
                        col.label('...')
                        break
                    col.label(subsequence.name)
            if vseqf.quicklist_sort == 'POSITION' and not hasattr(sequence, 'input_1'):
                col = column.column(align=True)
                col.operator('vseqf.quicklist_up', text='', icon='TRIA_UP').sequence = sequence.name
                col.operator('vseqf.quicklist_down', text='', icon='TRIA_DOWN').sequence = sequence.name

class VSEQFQuickListUp(bpy.types.Operator):
    """Attempts to switch a sequence with the previous sequence
    If no previous sequence is found, nothing is done
    
    Argument:
        sequence: String, the name of the sequence to switch"""

    bl_idname = "vseqf.quicklist_up"
    bl_label = "VSEQF Quick List Move Sequence Up"
    bl_description = "Move Sequence Up One"
    
    sequence = bpy.props.StringProperty()
    
    def execute(self, context):
        sequences = context.sequences
        for sequence in sequences:
            if sequence.name == self.sequence:
                switchwith = find_close_sequence(sequences=sequences, selected_sequence=sequence, direction='previous', mode='all', sounds=True, effects=False, children=not context.scene.vseqf.children)
                if switchwith:
                    swap_sequence(switchwith, sequence)
                break
        return {'FINISHED'}

class VSEQFQuickListDown(bpy.types.Operator):
    """Attempts to switch a sequence with the next sequence
    If no next sequence is found, nothing is done
    
    Argument:
        sequence: String, the name of the sequence to switch"""

    bl_idname = "vseqf.quicklist_down"
    bl_label = "VSEQF Quick List Move Sequence Down"
    bl_description = "Move Sequence Down One"
    
    sequence = bpy.props.StringProperty()
    
    def execute(self, context):
        sequences = context.sequences
        for sequence in sequences:
            if sequence.name == self.sequence:
                switchwith = find_close_sequence(sequences=sequences, selected_sequence=sequence, direction='next', mode='all', sounds=True, effects=False, children=not context.scene.vseqf.children)
                if switchwith:
                    swap_sequence(sequence, switchwith)
                break
        return {'FINISHED'}

class VSEQFQuickListSelect(bpy.types.Operator):
    """Toggle-selects a sequence by its name
    Argument:
        sequence: String, name of the sequence to select.  If blank, all sequences will be toggle-selected"""
    
    bl_idname = "vseqf.quicklist_select"
    bl_label = "VSEQF Quick List Select Sequence"

    sequence = bpy.props.StringProperty()

    def execute(self, context):
        sequences = context.sequences
        if (self.sequence == ''):
            bpy.ops.sequencer.select_all(action='TOGGLE')
        else:
            for sequence in sequences:
                if (sequence.name == self.sequence):
                    sequence.select = not sequence.select
        return {'FINISHED'}


#Classes related to QuickMarkers
class VSEQFQuickMarkersPanel(bpy.types.Panel):
    """Panel for QuickMarkers operators and properties"""
    bl_label = "Quick Markers"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    
    @classmethod
    def poll(self, context):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        return prefs.markers
        
    def draw(self, context):
        scene = bpy.context.scene
        vseqf = scene.vseqf
        layout = self.layout
        
        row = layout.row()
        split = row.split(percentage=.9,align=True)
        split.prop(vseqf, 'current_marker')
        split.operator('vseqf.quickmarkers_add_preset', text="", icon="PLUS").preset = vseqf.current_marker
        row = layout.row()
        row.template_list("VSEQFQuickMarkerPresetList", "", vseqf, 'marker_presets', vseqf, 'marker_index', rows=2)
        row = layout.row()
        row.prop(vseqf, 'marker_deselect', toggle=True)
        row = layout.row()
        row.label("Marker List:")
        row = layout.row()
        row.template_list("VSEQFQuickMarkerList", "", scene, "timeline_markers", scene.vseqf, "marker_index", rows=4)

class VSEQFQuickMarkerPresetList(bpy.types.UIList):
    """Draws an editable list of QuickMarker presets"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(percentage=.9, align=True)
        split.operator('vseqf.quickmarkers_place', text=item.text).marker = item.text
        split.operator('vseqf.quickmarkers_remove_preset', text='', icon='X').marker = item.text

    def draw_filter(self, context, layout):
        pass

    def filter_items(self, context, data, property):
        flt_neworder = []
        markers = getattr(data, property)
        helper = bpy.types.UI_UL_list
        flt_neworder = helper.sort_items_by_name(markers, 'text')
        return [], flt_neworder

class VSEQFQuickMarkerList(bpy.types.UIList):
    """Draws an editable list of current markers in the timeline"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        timecode = timecode_from_frames(item.frame, (context.scene.render.fps / context.scene.render.fps_base), levels=0, subsecond_type='frames')
        split = layout.split(percentage=.9, align=True)
        subsplit = split.split(align=True)
        subsplit.operator('vseqf.quickmarkers_jump', text=item.name+' ('+timecode+')').frame = item.frame
        if item.frame == context.scene.frame_current:
            subsplit.enabled = False
        split.operator('vseqf.quickmarkers_delete', text='', icon='X').frame = item.frame

    def draw_filter(self, context, layout):
        pass
        
    def filter_items(self, context, data, property):
        flt_neworder = []
        markers = getattr(data, property)
        helper = bpy.types.UI_UL_list
        flt_neworder = helper.sort_items_helper(list(enumerate(markers)), key=lambda x: x[1].frame)
        return [], flt_neworder

class VSEQFQuickMarkerDelete(bpy.types.Operator):
    """Operator to delete a marker on a given frame
    If no marker is on the frame, nothing will be done
    
    Argument:
        frame: Integer, the frame to delete a marker from"""
    
    bl_idname = 'vseqf.quickmarkers_delete'
    bl_label = 'Delete Marker At Frame'
    
    frame = bpy.props.IntProperty()
    
    def execute(self, context):
        scene = context.scene
        markers = scene.timeline_markers
        for marker in markers:
            if marker.frame == self.frame:
                markers.remove(marker)
                break
        return{'FINISHED'}

class VSEQFQuickMarkerJump(bpy.types.Operator):
    """Operator to move the cursor to a given frame
    Note that a marker doesn't have to be at the frame, that is just the way the script uses this.
    
    Argument:
        frame: Integer, the frame number to jump to"""
    bl_idname = 'vseqf.quickmarkers_jump'
    bl_label = 'Jump To Timeline Marker'
    
    frame = bpy.props.IntProperty()
    
    def execute(self, context):
        scene = context.scene
        scene.frame_current = self.frame
        return{'FINISHED'}

class VSEQFQuickMarkersMenu(bpy.types.Menu):
    """Menu for adding QuickMarkers to the current frame of the timeline"""
    bl_idname = "vseqf.quickmarkers_menu"
    bl_label = "Quick Markers"
    
    @classmethod
    def poll(self, context):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        return prefs.markers

    def draw(self, context):
        scene = bpy.context.scene   
        vseqf = scene.vseqf
        layout = self.layout
        for marker in vseqf.marker_presets:
            layout.operator('vseqf.quickmarkers_place', text=marker.text).marker = marker.text

class VSEQFQuickMarkersPlace(bpy.types.Operator):
    """Adds a marker with a specific name to the current frame of the timeline
    If a marker already exists at the current frame, it will be renamed
    
    Argument:
        marker: String, the name of the marker to place"""

    bl_idname = 'vseqf.quickmarkers_place'
    bl_label = 'VSEQF Quick Markers Place A Marker'
    
    marker = bpy.props.StringProperty()
    
    def execute(self, context):
        scene = context.scene
        vseqf = scene.vseqf
        frame = scene.frame_current
        exists = False
        for marker in scene.timeline_markers:
            if marker.frame == frame:
                marker.name = self.marker
                if vseqf.marker_deselect:
                    marker.select = False
                exists = True
        if not exists:
            marker = scene.timeline_markers.new(name=self.marker, frame=frame)
            if vseqf.marker_deselect:
                marker.select = False
        return{'FINISHED'}

class VSEQFQuickMarkersRemovePreset(bpy.types.Operator):
    """Removes a marker name preset from the QuickMarkers preset list
    
    Argument:
        marker: String, the name of the marker preset to be removed"""

    bl_idname = 'vseqf.quickmarkers_remove_preset'
    bl_label = 'VSEQF Quick Markers Remove Preset'
    
    #marker name to be removed
    marker = bpy.props.StringProperty()
    
    def execute(self, context):
        vseqf = context.scene.vseqf
        for index, marker_preset in reversed(list(enumerate(vseqf.marker_presets))):
            if marker_preset.text == self.marker:
                vseqf.marker_presets.remove(index)
        return{'FINISHED'}

class VSEQFQuickMarkersAddPreset(bpy.types.Operator):
    """Adds a name preset to QuickMarkers presets
    If the name already exists in the presets, the operator is canceled
    
    Argument:
        preset: String, the name of the marker preset to add"""

    bl_idname = 'vseqf.quickmarkers_add_preset'
    bl_label = 'VSEQF Quick Markers Add Preset'
    
    preset = bpy.props.StringProperty()
    
    def execute(self, context):
        vseqf = context.scene.vseqf
        for marker_preset in vseqf.marker_presets:
            if marker_preset.text == self.preset:
                return{'CANCELLED'}
        preset = vseqf.marker_presets.add()
        preset.text = self.preset
        return{'FINISHED'}


#Functions and classes related to Quick Batch Render
def batch_render_complete_handler(scene):
    """Handler called when each element of a batch render is completed"""

    scene.vseqf.batch_rendering = False
    handlers = bpy.app.handlers.render_complete
    for handler in handlers:
        if ("batch_render_complete_handler" in str(handler)):
            handlers.remove(handler)

def batch_render_cancel_handler(scene):
    """Handler called when the user cancels a render that is part of a batch render"""

    scene.vseqf.batch_rendering_cancel = True
    handlers = bpy.app.handlers.render_cancel
    for handler in handlers:
        if ("batch_render_cancel_handler" in str(handler)):
            handlers.remove(handler)

class VSEQFQuickBatchRenderPanel(bpy.types.Panel):
    """Panel for displaying QuickBatchRender settings and operators"""

    bl_label = "Quick Batch Render"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    
    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        #Check for sequences
        if not bpy.context.sequences:
            return False
        if len(bpy.context.sequences) > 0:
            return prefs.batch
        else:
            return False
    
    def draw(self, contex):
        scene = bpy.context.scene
        vseqf = scene.vseqf
        
        layout = self.layout
        row = layout.row()
        row.operator('vseqf.quickbatchrender', text='Batch Render')
        row = layout.row()
        row.prop(vseqf, 'batch_render_directory')
        row = layout.row()
        row.prop(vseqf, 'batch_selected', toggle=True)
        row = layout.row()
        row.prop(vseqf, 'batch_effects', toggle=True)
        row.prop(vseqf, 'batch_audio', toggle=True)
        row = layout.row()
        row.prop(vseqf, 'batch_meta')
        box = layout.box()
        row = box.row()
        row.label("Render Presets:")
        row = box.row()
        row.prop(vseqf, 'video_settings_menu', text='Opaque Strips')
        row = box.row()
        row.prop(vseqf, 'transparent_settings_menu', text='Transparent Strips')
        row = box.row()
        row.prop(vseqf, 'audio_settings_menu', text='Audio Strips')

class VSEQFQuickBatchRender(bpy.types.Operator):
    """Modal operator that runs a batch render on all sequences in the timeline"""

    bl_idname = 'vseqf.quickbatchrender'
    bl_label = 'VSEQF Quick Batch Render'
    bl_description = 'Renders out sequences in the timeline to a folder and reimports them.'

    _timer = None

    continuous = bpy.props.BoolProperty(default=False)
    rendering = bpy.props.BoolProperty(default=False)
    renders = []
    rendering_sequence = None
    rendering_scene = None
    original_scene = None
    file = bpy.props.StringProperty('')
    total_renders = bpy.props.IntProperty(0)
    total_frames = bpy.props.IntProperty(0)
    audio_frames = bpy.props.IntProperty(0)
    rendering_scene_name = ''

    def set_render_settings(self, scene, setting, transparent):
        """Applies a render setting preset to a given scene
        
        Arguments:
            scene: Scene object to apply the settings to
            setting: String, the setting preset name to apply.  Accepts values in the vseqf setting 'video_settings_menu'
            transparent: Boolean, whether this scene should be set up to render transparency or not"""
        
        pixels = scene.render.resolution_x * scene.render.resolution_y * (scene.render.resolution_percentage / 100)
        if setting == 'DEFAULT':
            if transparent:
                scene.render.image_settings.color_mode = 'RGBA'
            else:
                scene.render.image_settings.color_mode = 'RGB'
        elif setting == 'AVIJPEG':
            scene.render.image_settings.file_format = 'AVI_JPEG'
            scene.render.image_settings.color_mode = 'RGB'
            scene.render.image_settings.quality = 95
        elif setting == 'H264':
            #Blender 2.79 will change this setting, so this is to ensure backwards compatibility
            try:
                scene.render.image_settings.file_format = 'H264'
            except:
                scene.render.image_settings.file_format = 'FFMPEG'
            scene.render.image_settings.color_mode = 'RGB'
            scene.render.ffmpeg.format = 'MPEG4'
            kbps = int(pixels/230)
            maxkbps = kbps*1.2
            scene.render.ffmpeg.maxrate = maxkbps
            scene.render.ffmpeg.video_bitrate = kbps
            scene.render.ffmpeg.audio_codec = 'NONE'
        elif setting == 'JPEG':
            scene.render.image_settings.file_format = 'JPEG'
            scene.render.image_settings.color_mode = 'RGB'
            scene.render.image_settings.quality = 95
        elif setting == 'PNG':
            scene.render.image_settings.file_format = 'PNG'
            if transparent:
                scene.render.image_settings.color_mode = 'RGBA'
            else:
                scene.render.image_settings.color_mode = 'RGB'
            scene.render.image_settings.color_depth = '8'
            scene.render.image_settings.compression = 90
        elif setting == 'TIFF':
            scene.render.image_settings.file_format = 'TIFF'
            if transparent:
                scene.render.image_settings.color_mode = 'RGBA'
            else:
                scene.render.image_settings.color_mode = 'RGB'
            scene.render.image_settings.color_depth = '16'
            scene.render.image_settings.tiff_codec = 'DEFLATE'
        elif setting == 'EXR':
            scene.render.image_settings.file_format = 'OPEN_EXR'
            if transparent:
                scene.render.image_settings.color_mode = 'RGBA'
            else:
                scene.render.image_settings.color_mode = 'RGB'
            scene.render.image_settings.color_depth = '32'
            scene.render.image_settings.exr_codec = 'ZIP'

    def copy_curves(self, copy_from, copy_to, scene_from, scene_to):
        """Copies animation curves from one sequence to another, this is needed since the copy operator doesn't do this...
        Arguments:
            copy_from: VSE Sequence object to copy from
            copy_to: VSE Sequence object to copy to"""
        if hasattr(scene_from.animation_data, 'action'):
            scene_to.animation_data_create()
            scene_to.animation_data.action = bpy.data.actions.new(name=scene_to.name+'Action')
            for fcurve in scene_from.animation_data.action.fcurves:
                path = fcurve.data_path
                path_start = path.split('[', 1)[0]
                path_end = path.split(']')[-1]
                test_path = path_start+'["'+copy_from.name+'"]'+path_end
                if path == test_path:
                    new_path = path_start+'["'+copy_to.name+'"]'+path_end
                    new_curve = scene_to.animation_data.action.fcurves.new(data_path=new_path)
                    new_curve.extrapolation = fcurve.extrapolation
                    new_curve.mute = fcurve.mute
                    #copy keyframe points to new_curve
                    for keyframe in fcurve.keyframe_points:
                        new_curve.keyframe_points.add()
                        new_keyframe = new_curve.keyframe_points[-1]
                        new_keyframe.type = keyframe.type
                        new_keyframe.amplitude = keyframe.amplitude
                        new_keyframe.back = keyframe.back
                        new_keyframe.co = keyframe.co
                        new_keyframe.easing = keyframe.easing
                        new_keyframe.handle_left = keyframe.handle_left
                        new_keyframe.handle_left_type = keyframe.handle_left_type
                        new_keyframe.handle_right = keyframe.handle_right
                        new_keyframe.handle_right_type = keyframe.handle_right_type
                        new_keyframe.interpolation = keyframe.interpolation
                        new_keyframe.period = keyframe.period
                    new_curve.update()

    def render_sequence(self, sequence):
        """Begins rendering process: creates a temporary scene, sets it up, copies the sequence to the temporary scene, and begins rendering
        Arguments:
            sequence: VSE Sequence object to begin rendering"""

        self.rendering = True
        
        self.rendering_sequence = sequence
        self.original_scene = bpy.context.scene
        bpy.ops.sequencer.select_all(action='DESELECT')
        sequence.select = True
        #bpy.ops.sequencer.duplicate()
        bpy.ops.sequencer.copy()
        #bpy.ops.sequencer.delete()
        
        #create a temporary scene
        bpy.ops.scene.new(type='EMPTY')
        self.rendering_scene = bpy.context.scene
        self.rendering_scene_name = self.rendering_scene.name
        
        #copy sequence to new scene and set up scene
        bpy.ops.sequencer.paste()
        temp_sequence = self.rendering_scene.sequence_editor.sequences[0]
        self.copy_curves(sequence, temp_sequence, self.original_scene, self.rendering_scene)
        self.rendering_scene.frame_start = temp_sequence.frame_final_start
        #temp_sequence.frame_start = temp_sequence.frame_start - temp_sequence.frame_final_start + 1
        self.rendering_scene.frame_end = temp_sequence.frame_final_end - 1
        filename = sequence.name
        if self.original_scene.vseqf.batch_render_directory:
            path = self.original_scene.vseqf.batch_render_directory
        else:
            path = self.rendering_scene.render.filepath
        self.rendering_scene.render.filepath = os.path.join(path, filename)
        
        #render
        if sequence.type != 'SOUND':
            if sequence.blend_type in ['OVER_DROP', 'ALPHA_OVER']:
                transparent = True
                setting = self.original_scene.vseqf.transparent_settings_menu
            else:
                transparent = False
                setting = self.original_scene.vseqf.video_settings_menu
            self.set_render_settings(self.rendering_scene, setting, transparent)

            if not self.original_scene.vseqf.batch_effects:
                temp_sequence.modifiers.clear()
            self.file = self.rendering_scene.render.frame_path(frame=1)
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
            self.rendering_scene.vseqf.batch_rendering = True
            if 'batch_render_complete_handler' not in str(bpy.app.handlers.render_complete):
                bpy.app.handlers.render_complete.append(batch_render_complete_handler)
            if 'batch_render_cancel_handler' not in str(bpy.app.handlers.render_cancel):
                bpy.app.handlers.render_cancel.append(batch_render_cancel_handler)
            if self._timer:
                bpy.context.window_manager.event_timer_remove(self._timer)
            self._timer = bpy.context.window_manager.event_timer_add(1, bpy.context.window)
        else:
            format = self.original_scene.vseqf.audio_settings_menu
            if format == 'FLAC':
                extension = '.flac'
                container = 'FLAC'
                codec = 'FLAC'
            elif format == 'WAV':
                extension = '.wav'
                container = 'WAV'
                codec = 'PCM'
            elif format == 'MP3':
                extension = '.mp3'
                container = 'MP3'
                codec = 'MP3'
            elif format == 'OGG':
                extension = '.ogg'
                container = 'OGG'
                codec = 'VORBIS'
            bpy.ops.sound.mixdown(filepath=self.rendering_scene.render.filepath+extension, format='S16', bitrate=192, container=container, codec=codec)
            self.file = self.rendering_scene.render.filepath+extension
            self.rendering_scene.vseqf.batch_rendering = False
            if self._timer:
                bpy.context.window_manager.event_timer_remove(self._timer)
            self._timer = bpy.context.window_manager.event_timer_add(1, bpy.context.window)

    def copy_settings(self, sequence, new_sequence):
        """Copies the needed settings from the original sequence to the newly imported sequence
        Arguments:
            sequence: VSE Sequence, the original
            new_sequence: VSE Sequence, the sequence to copy the settings to"""

        new_sequence.lock = sequence.lock
        new_sequence.parent = sequence.parent
        new_sequence.blend_alpha = sequence.blend_alpha
        new_sequence.blend_type = sequence.blend_type
        if new_sequence.type != 'SOUND':
            new_sequence.alpha_mode = sequence.alpha_mode

    def finish_render(self):
        """Finishes the process of rendering a sequence by replacing the original sequence, and deleting the temporary scene"""
        bpy.context.screen.scene = self.rendering_scene
        try:
            bpy.ops.render.view_cancel()
        except:
            pass
        if self.rendering_sequence.type != 'SOUND':
            file_format = self.rendering_scene.render.image_settings.file_format
            if file_format in ['AVI_JPEG', 'AVI_RAW', 'FRAMESERVER', 'H264', 'FFMPEG', 'THEORA', 'XVID']:
                #delete temporary scene
                bpy.ops.scene.delete()
                bpy.context.screen.scene = self.original_scene
                new_sequence = self.original_scene.sequence_editor.sequences.new_movie(name=self.rendering_sequence.name+' rendered', filepath=self.file, channel=self.rendering_sequence.channel, frame_start=self.rendering_sequence.frame_final_start)
            else:
                head, tail = os.path.split(self.file)
                files = []
                for frame in range(2, self.rendering_scene.frame_end):
                    files.append(os.path.split(self.rendering_scene.render.frame_path(frame=frame))[1])
                #delete temporary scene
                bpy.ops.scene.delete()
                bpy.context.screen.scene = self.original_scene
                new_sequence = self.original_scene.sequence_editor.sequences.new_image(name=self.rendering_sequence.name+' rendered', filepath=self.file, channel=self.rendering_sequence.channel, frame_start=self.rendering_sequence.frame_final_start)
                for file in files:
                    new_sequence.elements.append(file)
        else:
            #delete temporary scene
            bpy.ops.scene.delete()
            bpy.context.screen.scene = self.original_scene
            
            new_sequence = self.original_scene.sequence_editor.sequences.new_sound(name=self.rendering_sequence.name+' rendered', filepath=self.file, channel=self.rendering_sequence.channel, frame_start=self.rendering_sequence.frame_final_start)
        #replace sequence
        bpy.ops.sequencer.select_all(action='DESELECT')
        self.copy_settings(self.rendering_sequence, new_sequence)
        self.rendering_sequence.select = True
        new_sequence.select = True
        self.original_scene.sequence_editor.active_strip = self.rendering_sequence

        for other_sequence in self.original_scene.sequence_editor.sequences_all:
            if hasattr(other_sequence, 'input_1'):
                if other_sequence.input_1 == self.rendering_sequence:
                    other_sequence.input_1 = new_sequence
            if hasattr(other_sequence, 'input_2'):
                if other_sequence.input_2 == self.rendering_sequence:
                    other_sequence.input_2 = new_sequence
        if not self.original_scene.vseqf.batch_effects:
            bpy.ops.sequencer.strip_modifier_copy(type='REPLACE')
        
        new_sequence.select = False
        bpy.ops.sequencer.delete()

    def next_render(self):
        """Starts rendering the next sequence in the list"""

        sequence = self.renders.pop(0)
        print('rendering '+sequence.name)
        self.render_sequence(sequence)
    
    def modal(self, context, event):
        """Main modal function, handles the render list"""
        
        if not self.rendering_scene:
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            return {'CANCELLED'}
        if not bpy.data.scenes.get(self.rendering_scene_name, False):
            #the user deleted the rendering scene, uh-oh...
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            #todo: need to cancel the render here so blender doesn't crash... somehow
            return {'CANCELLED'}
        if event.type == 'TIMER':
            if not self.rendering_scene.vseqf.batch_rendering:
                if self._timer:
                    context.window_manager.event_timer_remove(self._timer)
                    self._timer = None
                self.finish_render()
                if len(self.renders) > 0:
                    self.next_render()
                    self.report({'INFO'}, "Rendered "+str(self.total_renders - len(self.renders))+" out of "+str(self.total_renders)+" files.  "+str(self.total_frames)+" frames total.")
                else:
                    self.rendering_scene.vseqf.continuous_enable = self.continuous
                    return {'FINISHED'}

            return {'PASS_THROUGH'}
        if self.rendering_scene.vseqf.batch_rendering_cancel:
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            self.renders.clear()
            try:
                bpy.ops.render.view_cancel()
            except:
                pass
            try:
                self.rendering_scene.user_clear()
                bpy.data.scenes.remove(self.rendering_scene)
                context.screen.scene = self.original_scene
                context.screen.scene.update()
                context.window_manager.update_tag()
            except:
                pass
            return {'CANCELLED'}
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        """Called when the batch render is initialized.  Sets up variables and begins the rendering process."""
        
        context.window_manager.modal_handler_add(self)
        self.rendering = False
        self.finished_queue = False
        oldscene = context.scene
        vseqf = oldscene.vseqf
        self.continuous = vseqf.continuous_enable
        name = oldscene.name + ' Batch Render'
        bpy.ops.scene.new(type='FULL_COPY')
        newscene = context.scene
        newscene.name = name
        newscene.vseqf.continuous_enable = False
        
        if vseqf.batch_meta == 'SUBSTRIPS':
            old_sequences = newscene.sequence_editor.sequences_all
        else:
            old_sequences = newscene.sequence_editor.sequences
        
        #queue up renders
        self.total_frames = 0
        self.audio_frames = 0
        self.renders = []
        for sequence in old_sequences:
            if (vseqf.batch_selected and sequence.select) or not vseqf.batch_selected:
                if sequence.type == 'MOVIE' or sequence.type == 'IMAGE' or sequence.type == 'MOVIECLIP':
                    #standard video or image sequence
                    self.renders.append(sequence)
                    self.total_frames = self.total_frames + sequence.frame_final_duration
                elif sequence.type == 'SOUND':
                    #audio sequence
                    if vseqf.batch_audio:
                        self.renders.append(sequence)
                        self.audio_frames = self.audio_frames + sequence.frame_final_duration
                elif sequence.type == 'META':
                    #meta sequence
                    if vseqf.batch_meta == 'SINGLESTRIP':
                        self.renders.append(sequence)
                        self.total_frames = self.total_frames + sequence.frame_final_duration
                else:
                    #other sequence type, not handled
                    pass
        self.total_renders = len(self.renders)
        if self.total_renders > 0:
            self.next_render()
            return {'RUNNING_MODAL'}
        else:
            return {'CANCELLED'}


#Functions and classes related to QuickTags
def populate_tags(sequences=False, tags=False):
    """Iterates through all sequences and stores all tags to the 'tags' property group
    If no sequences are given, default to all sequences in context.
    If no tags group is given, default to scene.vseqf.tags"""
    
    if sequences == False:
        sequences = bpy.context.sequences
    if tags == False:
        tags = bpy.context.scene.vseqf.tags
    
    temp_tags = set()
    for sequence in sequences:
        for tag in sequence.tags:
            temp_tags.add(tag.text)
    tags.clear()
    add_tags = sorted(temp_tags)
    for tag in add_tags:
        new_tag = tags.add()
        new_tag.text = tag

class VSEQFQuickTagsPanel(bpy.types.Panel):
    """Panel for displaying, removing and adding tags"""

    bl_label = "Quick Tags"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    
    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        #Check for sequences
        if not bpy.context.sequences or not bpy.context.scene.sequence_editor:
            return False
        if len(bpy.context.sequences) > 0 and bpy.context.scene.sequence_editor.active_strip:
            return prefs.tags
        else:
            return False

    def draw(self, context):
        scene = context.scene
        vseqf = scene.vseqf
        sequence = scene.sequence_editor.active_strip
        layout = self.layout
        
        row = layout.row()
        row.label('All Tags:')
        row = layout.row()
        row.template_list("VSEQFQuickTagListAll", "", vseqf, 'tags', vseqf, 'marker_index')
        row = layout.row()
        split = row.split(percentage=.9,align=True)
        split.prop(vseqf, 'current_tag')
        split.operator('vseqf.quicktags_add', text="", icon="PLUS").text = vseqf.current_tag
        row = layout.row()
        split = row.split(percentage=.5)
        if vseqf.continuous_enable and vseqf.show_selected_tags:
            split.label('Selected Tags:')
            split.prop(vseqf, 'show_selected_tags', text='Show All Selected', toggle=True)
            row = layout.row()
            row.template_list("VSEQFQuickTagList", "", vseqf, 'selected_tags', vseqf, 'marker_index', rows=2)
        else:
            split.label('Active Tags:')
            if vseqf.continuous_enable:
                split.prop(vseqf, 'show_selected_tags', text='Show All Selected', toggle=True)
            row = layout.row()
            row.template_list("VSEQFQuickTagList", "", sequence, 'tags', vseqf, 'marker_index', rows=2)
        row = layout.row()
        row.operator('vseqf.quicktags_clear', text='Clear Selected Tags')

class VSEQFQuickTagListAll(bpy.types.UIList):
    """Draws a list of tags"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(percentage=.9, align=True)
        split.operator('vseqf.quicktags_select', text=item.text).text = item.text
        split.operator('vseqf.quicktags_add', text='', icon="PLUS").text = item.text

    def draw_filter(self, context, layout):
        pass

class VSEQFQuickTagList(bpy.types.UIList):
    """Draws an editable list of tags"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        split = layout.split(percentage=.9, align=True)
        split.operator('vseqf.quicktags_select', text=item.text).text = item.text
        split.operator('vseqf.quicktags_remove', text='', icon='X').text = item.text

    def draw_filter(self, context, layout):
        pass

    def filter_items(self, context, data, property):
        flt_neworder = []
        tags = getattr(data, property)
        helper = bpy.types.UI_UL_list
        flt_neworder = helper.sort_items_by_name(tags, 'text')
        return [], flt_neworder

class VSEQFQuickTagsClear(bpy.types.Operator):
    """Clears all tags on the selected and active sequences"""

    bl_idname = 'vseqf.quicktags_clear'
    bl_label = 'VSEQF Quick Tags Clear'
    bl_description = 'Clear all tags on all selected sequences'
    
    def execute(self, context):
        sequences = context.selected_sequences
        for sequence in sequences:
            sequence.tags.clear()
        populate_tags()
        return{'FINISHED'}

class VSEQFQuickTagsSelect(bpy.types.Operator):
    """Selects sequences with the given tag name
    Argument:
        text: String, the name of the tag to find sequences with"""

    bl_idname = 'vseqf.quicktags_select'
    bl_label = 'VSEQF Quick Tags Select'
    bl_description = 'Select all strips with this tag'
    
    text = bpy.props.StringProperty()
    
    def execute(self, context):
        new_active = None
        strips = context.scene.sequence_editor.sequences
        for strip in strips:
            strip.select = False
            for tag in strip.tags:
                if tag.text == self.text:
                    strip.select = True
                    new_active = strip
                    break

        if not context.scene.sequence_editor.active_strip.select and new_active:
            context.scene.sequence_editor.active_strip = new_active
        context.scene.vseqf.current_tag = self.text
        populate_tags()
        return{'FINISHED'}

class VSEQFQuickTagsRemoveFrom(bpy.types.Operator):
    """Removes a tag from a specified sequence
    Argument:
        tag: String, a tag and sequence name separated by a next line"""
    bl_idname = 'vseqf.quicktags_remove_from'
    bl_label = 'VSEQF Quick Tags Remove From'
    bl_description = 'Remove this tag from this sequence'
    
    tag = bpy.props.StringProperty()
    
    def execute(self, context):
        if '\n' in self.tag:
            text, sequence_name = self.tag.split('\n')
            if text and sequence_name:
                sequences = context.sequences
                for sequence in sequences:
                    if sequence.name == sequence_name:
                        for index, tag in reversed(list(enumerate(sequence.tags))):
                            if tag.text == text:
                                sequence.tags.remove(index)
        
        populate_tags()
        return{'FINISHED'}

class VSEQFQuickTagsRemove(bpy.types.Operator):
    """Remove tags with a specific name from all selected sequences
    Argument:
        text: String, tag text to remove"""
    bl_idname = 'vseqf.quicktags_remove'
    bl_label = 'VSEQF Quick Tags Remove'
    bl_description = 'Remove this tag from all selected sequences'
    
    text = bpy.props.StringProperty()
    
    def execute(self, context):
        sequences = context.selected_sequences
        sequences.append(context.scene.sequence_editor.active_strip)
        for sequence in sequences:
            for index, tag in reversed(list(enumerate(sequence.tags))):
                if tag.text == self.text:
                    sequence.tags.remove(index)

        populate_tags()
        return{'FINISHED'}

class VSEQFQuickTagsAdd(bpy.types.Operator):
    """Adds a tag with the given text to the selected and active sequences
    Argument:
        text: String, tag to add"""
    bl_idname = 'vseqf.quicktags_add'
    bl_label = 'VSEQF Quick Tags Add'
    bl_description = 'Add this tag to all selected sequences'
    
    text = bpy.props.StringProperty()
    
    def execute(self, context):
        text = self.text.replace("\n", '')
        if text:
            sequences = context.selected_sequences
            for sequence in sequences:
                tag_found = False
                for tag in sequence.tags:
                    if tag.text == text:
                        tag_found = True
                if not tag_found:
                    tag = sequence.tags.add()
                    tag.text = text

            populate_tags()
        return{'FINISHED'}


#Classes related to QuickCuts
class VSEQFQuickCutsMenu(bpy.types.Menu):
    """Popup Menu for QuickCuts operators and properties"""

    bl_idname = "vseqf.quickcuts_menu"
    bl_label = "Quick Cuts"

    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        #Check for sequences
        if not bpy.context.sequences or not bpy.context.scene.sequence_editor:
            return False
        if len(bpy.context.sequences) > 0:
            return prefs.cuts
        else:
            return False

    def draw(self, context):
        layout = self.layout
        layout.operator('vseqf.quickcuts', text='Cut').operation = 'cut'
        layout.operator('vseqf.quickcuts', text='Cut Insert').operation = 'cut_insert'
        layout.operator('vseqf.quickcuts', text='UnCut Left', icon='BACK').operation = 'uncut_left'
        layout.operator('vseqf.quickcuts', text='UnCut Right', icon='FORWARD').operation = 'uncut_right'
        layout.operator('vseqf.quickcuts', text='Delete', icon='X').operation = 'delete'
        layout.operator('vseqf.quickcuts', text='Ripple Delete', icon='X').operation = 'ripple_delete'
        layout.separator()
        layout.operator('vseqf.quickcuts', text='Trim Left', icon='BACK').operation = 'trim_left'
        layout.operator('vseqf.quickcuts', text='Trim Right', icon='FORWARD').operation = 'trim_right'
        layout.operator('vseqf.quickcuts', text='Slide Trim Left', icon='BACK').operation = 'slide_trim_left'
        layout.operator('vseqf.quickcuts', text='Ripple Trim Left', icon='BACK').operation = 'ripple_trim_left'
        layout.operator('vseqf.quickcuts', text='Ripple Trim Right', icon='FORWARD').operation = 'ripple_trim_right'
        layout.separator()
        layout.prop(context.scene.vseqf, 'quickcuts_all', toggle=True)
        layout.prop(context.scene.vseqf, 'quickcuts_insert')
        layout.label('')
        layout.separator()
        layout.operator('vseqf.quicktimeline', text='Timeline To All').operation = 'sequences'
        layout.operator('vseqf.quicktimeline', text='Timeline To Selected').operation = 'selected'
        layout.separator()
        layout.operator('vseqf.quicktimeline', text='Timeline Start To All').operation = 'sequences_start'
        layout.operator('vseqf.quicktimeline', text='Timeline End To All').operation = 'sequences_end'
        layout.operator('vseqf.quicktimeline', text='Timeline Start To Selected').operation = 'selected_start'
        layout.operator('vseqf.quicktimeline', text='Timeline End To Selected').operation = 'selected_end'

class VSEQFQuickCutsPanel(bpy.types.Panel):
    """Panel for QuickCuts operators and properties"""

    bl_label = "Quick Cuts"
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    
    @classmethod
    def poll(self, context):
        #Check if panel is disabled
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        #Check for sequences
        if not bpy.context.sequences or not bpy.context.scene.sequence_editor:
            return False
        if len(bpy.context.sequences) > 0:
            return prefs.cuts
        else:
            return False

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.prop(context.scene.vseqf, 'quickcuts_all', toggle=True)
        row.prop(context.scene.vseqf, 'quickcuts_insert')
        box = layout.box()
        row = box.row()
        row.operator('vseqf.quickcuts', text='Cut').operation = 'cut'
        row.operator('vseqf.quickcuts', text='Cut Insert').operation = 'cut_insert'
        row = box.row(align=True)
        row.operator('vseqf.quickcuts', text='UnCut Left', icon='BACK').operation = 'uncut_left'
        row.operator('vseqf.quickcuts', text='UnCut Right', icon='FORWARD').operation = 'uncut_right'
        row = box.row()
        row.operator('vseqf.quickcuts', text='Delete', icon='X').operation = 'delete'
        row.operator('vseqf.quickcuts', text='Ripple Delete', icon='X').operation = 'ripple_delete'
        
        box = layout.box()
        row = box.row()
        split = row.split(percentage=.5, align=True)
        column = split.column(align=True)
        column.operator('vseqf.quickcuts', text='Trim Left', icon='BACK').operation = 'trim_left'
        column.operator('vseqf.quickcuts', text='Slide Trim Left', icon='BACK').operation = 'slide_trim_left'
        column.operator('vseqf.quickcuts', text='Ripple Trim Left', icon='BACK').operation = 'ripple_trim_left'
        
        column = split.column(align=True)
        column.operator('vseqf.quickcuts', text='Trim Right', icon='FORWARD').operation = 'trim_right'
        column.label('')
        column.operator('vseqf.quickcuts', text='Ripple Trim Right', icon='FORWARD').operation = 'ripple_trim_right'
        
        box = layout.box()
        row = box.row()
        split = row.split(percentage=.5, align=True)
        column = split.column(align=True)
        column.operator('vseqf.quicktimeline', text='Timeline To All').operation = 'sequences'
        column.operator('vseqf.quicktimeline', text='Start To All').operation = 'sequences_start'
        column.operator('vseqf.quicktimeline', text='Start To Selected').operation = 'selected_start'
        
        column = split.column(align=True)
        column.operator('vseqf.quicktimeline', text='Timeline To Selected').operation = 'selected'
        column.operator('vseqf.quicktimeline', text='End To All').operation = 'sequences_end'
        column.operator('vseqf.quicktimeline', text='End To Selected').operation = 'selected_end'

class VSEQFQuickCuts(bpy.types.Operator):
    """Operator to perform QuickCuts operations on sequences
    May apply the operation to all sequences, only selected sequences, or only the active
    
    Argument:
        operation: String, the operation to be performed on the sequences
            'cut': Cuts all, or the selected sequences
            'cut_insert': Cuts, then inserts a set number of frames in the cut space
            'trim_left': Trims off the left edge of all, or the selected sequences
            'slide_trim_left': Trims, then slides the trimmed sequences left to their old left edge
            'ripple_trim_left': Trims, slides, then moves all following sequences by the slide distance
            'trim_right': Trims off the right edge of all, or the selected sequences
            'ripple_trim_right': Trims, then moves all following sequences back by the trimmed amount
            'uncut_left': If the sequence to the left of the active sequence was previously cut from it, merge the two back together
            'uncut_right': Like uncut_left, but looks for the sequence to the right
            'delete': Deletes the selected strips without a confirmation dialog
            'ripple_delete': Deletes the selected strips, and moves following strips to fill the gap"""

    bl_idname = 'vseqf.quickcuts'
    bl_label = 'VSEQF Quick Cuts'
    
    operation = bpy.props.StringProperty()
    
    def check_source(self, sequence, next_sequence):
        """Used by UnCut, checks the source and position of two sequences to see if they can be merged
        
        Arguments:
            sequence: VSE Sequence object to be compared
            next_sequence: VSE Sequence object to be compared
            
        Returns: Boolean"""

        if sequence.type == next_sequence.type:
            if sequence.type == 'IMAGE':
                if sequence.directory == next_sequence.directory and sequence.elements[0].filename == next_sequence.elements[0].filename:
                    if len(sequence.elements) == 1 and len(next_sequence.elements) == 1:
                        return True
                    elif sequence.frame_start == next_sequence.frame_start:
                        return True
            elif sequence.frame_start == next_sequence.frame_start:
                if sequence.type == 'SOUND':
                    if sequence.sound.filepath == next_sequence.sound.filepath:
                        return True
                if sequence.type == 'MOVIE':
                    if sequence.filepath == next_sequence.filepath:
                        return True
                if sequence.type == 'SCENE':
                    if sequence.scene == next_sequence.scene:
                        return True
                if sequence.type == 'MOVIECLIP':
                    #no way of checking source file :\
                    pass
        return False

    def delete(self, sequences, ripple=False):
        """Deletes selected sequences, optionally ripples following sequences.
        
        Argument:
            sequences: List of VSE Sequence objects to modify"""

        sequences_to_check = []
        delete_sequences = []
        for sequence in sequences:
            if sequence.select:
                delete_sequences.append(sequence)
            else:
                sequences_to_check.append(sequence)
        for sequence in delete_sequences:
            if bpy.context.scene.sequence_editor.active_strip == sequence:
                fix_active_strip = True
            else:
                fix_active_strip = False
                bpy.context.scene.sequence_editor.active_strip = sequences_to_check[0]

            offset = sequence.frame_final_duration
            start_frame = sequence.frame_final_start
            end_frame = sequence.frame_final_end
            if bpy.context.scene.frame_current > start_frame:
                bpy.context.scene.frame_current = start_frame

            if bpy.context.scene.vseqf.children and bpy.context.scene.vseqf.delete_children:
                children = find_children(sequence)
                for child in children:
                    if child not in delete_sequences:
                        if child in sequences_to_check:
                            sequences_to_check.remove(child)
                        self.delete_sequence(child)
            self.delete_sequence(sequence)
            
            #move sequences after the deleted one up in the timeline
            update_sequences = sequences_after_frame(sequences_to_check, start_frame, add_locked=False, add_parented=(not bpy.context.scene.vseqf.children), add_effect=False)
            #organize by distance
            update_sequences = sorted(update_sequences, key=lambda x:x.frame_final_start)
            if fix_active_strip:
                bpy.context.scene.sequence_editor.active_strip = update_sequences[0]
            if ripple:
                #cache channels
                for seq in update_sequences:
                    seq.last_channel = seq.channel
                for seq in update_sequences:
                    #move sequences
                    if seq.frame_final_start >= end_frame:
                        seq.frame_start = seq.frame_start - offset
                    else:
                        move_amount = seq.frame_final_start - start_frame
                        seq.frame_start = seq.frame_start
                for seq in update_sequences:
                    seq.channel = seq.last_channel

    def delete_sequence(self, sequence):
        """Deletes a sequence while maintaining previous selected and active sequences
        Argument:
            sequence: VSE Sequence object to delete"""

        bpy.context.scene.sequence_editor.sequences.remove(sequence)

    def cut(self, sequences, frame, insert=0):
        """Cuts a passed in set of sequences.  Optionally can insert frames in the cut area
        The selected and active sequences are maintained by this function
        
        Arguments:
            sequences: List of VSE Sequence objects to cut
            frame: Integer, the frame to cut at
            insert: Optional, Integer number of frames to slide all sequences after the cut by"""

        #save the previously selected and active sequences
        selected = []
        active = bpy.context.scene.sequence_editor.active_strip
        for sequence in bpy.context.sequences:
            if sequence.select:
                selected.append(sequence)
                sequence.select = False

        #Cut the sequences
        for sequence in sequences:
            if not sequence.lock and (not hasattr(sequence, 'input_1')) and under_cursor(sequence, frame):
                sequence.select = True
                bpy.ops.sequencer.cut(frame=frame)
        
        #Restore the previous selected and active sequences
        for sequence in bpy.context.sequences:
            sequence.select = False
        for sequence in selected:
            sequence.select = True
        bpy.context.scene.sequence_editor.active_strip = active
        
        #Perform insert ripple if needed
        if insert > 0:
            check_sequences = sequences_after_frame(bpy.context.sequences, frame, add_locked=False, add_parented=(not bpy.context.scene.vseqf.children), add_effect=False)
            check_sequences = sorted(check_sequences, key=lambda x:x.frame_final_start)
            for sequence in check_sequences:
                sequence.frame_start = sequence.frame_start + insert

    def trim_left(self, sequences, frame, slide=False, ripple=False):
        """Trims off the left part of the passed in sequences
        
        Arguments:
            sequences: List of VSE Sequence objects to operate on
            frame: Integer frame number to cut the sequences at
            slide: Boolean, set to True to move the cut sequences back to the original left edge
            ripple: Boolean, set to True to move following sequences back along with the cut ones"""

        ripple_sequences = []
        cut_sequences = []
        move_amount = 0
        
        #determine distance sequences will be moved if rippled or slid.  Must be done beforehand to know how far to move the sequences
        if slide or ripple:
            for sequence in sequences:
                if not sequence.lock and under_cursor(sequence, frame):
                    cut_amount = frame - sequence.frame_final_start
                    has_parent = False
                    if bpy.context.scene.vseqf.children:
                        parent = find_parent(sequence)
                        if parent:
                            if parent in sequences:
                                has_parent = True
                    
                    if not has_parent:
                        if cut_amount > move_amount:
                            move_amount = cut_amount

        for sequence in sequences:
            if not sequence.lock and (not hasattr(sequence, 'input_1')) and under_cursor(sequence, frame):
                sequence.ignore_continuous = True
                cut_amount = frame - sequence.frame_final_start
                
                #cut child sequences if enabled and if they match the beginning frame
                if bpy.context.scene.vseqf.children and bpy.context.scene.vseqf.child_edges:
                    children = find_children(sequence)
                    for child in children:
                        if child not in sequences:
                            if child.frame_final_start == sequence.frame_final_start:
                                cut_sequences.append(child)
                                child.frame_final_start = child.frame_final_start + cut_amount
                sequence.frame_final_start = sequence.frame_final_start + cut_amount
                cut_sequences.append(sequence)
                if slide:
                    move_sequence = True
                    
                    if bpy.context.scene.vseqf.children:
                        for child in children:
                            if child not in sequences:
                                child.frame_start = child.frame_start - move_amount
                    sequence.frame_start = sequence.frame_start - move_amount
                if ripple:
                    check_sequences = sequences_after_frame(bpy.context.sequences, frame, add_locked=False, add_parented=True, add_effect=False)
                    for check in check_sequences:
                        if check not in ripple_sequences:
                            ripple_sequences.append(check)
        if slide or ripple:
            bpy.context.scene.frame_current = bpy.context.scene.frame_current - move_amount
        if ripple:
            ripple_sequences = sorted(ripple_sequences, key=lambda x:x.frame_final_start)
            for sequence in ripple_sequences:
                if sequence not in cut_sequences:
                    sequence.ignore_continuous = True
                    sequence.frame_start = sequence.frame_start - move_amount

    def trim_right(self, sequences, frame, ripple=False):
        """Trims off the right part of the passed in sequences
        
        Arguments:
            sequences: List of VSE Sequence objects to operate on
            frame: Integer frame number to cut the sequences at
            ripple: Boolean, set to True to move following sequences back the amount that was cut"""

        ripple_sequences = []
        move_amount = 0

        for sequence in sequences:
            if not sequence.lock and (not hasattr(sequence, 'input_1')) and under_cursor(sequence, frame):
                sequence.ignore_continuous = True
                cut_amount = sequence.frame_final_end - frame
                
                #cut child sequences if enabled and if they match the beginning frame
                if bpy.context.scene.vseqf.children and bpy.context.scene.vseqf.child_edges:
                    children = find_children(sequence)
                    for child in children:
                        if child not in sequences:
                            if child.frame_final_end == sequence.frame_final_end:
                                child.frame_final_end = frame

                sequence.frame_final_end = frame
                if cut_amount > move_amount:
                    move_amount = cut_amount
                if ripple:
                    check_sequences = sequences_after_frame(bpy.context.sequences, frame, add_locked=False, add_parented=True, add_effect=False)
                    for check in check_sequences:
                        if check not in ripple_sequences:
                            ripple_sequences.append(check)
        if ripple:
            ripple_sequences = sorted(ripple_sequences, key=lambda x:x.frame_final_start)
            for sequence in ripple_sequences:
                sequence.ignore_continuous = True
                sequence.frame_start = sequence.frame_start - move_amount

    def uncut(self, direction):
        """Merges the active sequence with a previously cut sequence, if they match up
        
        Arguments:
            direction: String, the direction to look for a sequence to merge to
                'next': look forward for the sequence
                'previous': look backward for the sequence"""

        sequence = bpy.context.scene.sequence_editor.active_strip
        merge_to = find_close_sequence(bpy.context.sequences, sequence, direction=direction, mode='channel', sounds=True)
        if merge_to:
            if not merge_to.lock:
                source_matches = self.check_source(sequence, merge_to)
                if source_matches:
                    merge_to_children = find_children(merge_to)
                    add_children(sequence, merge_to_children)
                    clear_children(merge_to)
                    sequence.ignore_continuous = True
                    children = find_children(sequence)
                    for child in children:
                        child.ignore_continuous = True
                    if direction == 'next':
                        newend = merge_to.frame_final_end
                        self.delete_sequence(merge_to)
                        sequence.frame_final_end = newend
                    else:
                        newstart = merge_to.frame_final_start
                        self.delete_sequence(merge_to)
                        sequence.frame_final_start = newstart
        
    def execute(self, context):
        if context.scene.vseqf.quickcuts_all:
            sequences = context.sequences
        else:
            sequences = context.selected_sequences
        frame = context.scene.frame_current
        operation = self.operation
        if operation == 'cut':
            self.cut(sequences, frame)
        elif operation == 'cut_insert':
            insert = context.scene.vseqf.quickcuts_insert
            self.cut(sequences, frame, insert=insert)
        elif operation == 'trim_left':
            self.trim_left(sequences, frame)
        elif operation == 'slide_trim_left':
            self.trim_left(sequences, frame, slide=True)
        elif operation == 'ripple_trim_left':
            self.trim_left(sequences, frame, slide=True, ripple=True)
        elif operation == 'trim_right':
            self.trim_right(sequences, frame)
        elif operation == 'ripple_trim_right':
            self.trim_right(sequences, frame, ripple=True)
        elif operation == 'uncut_left':
            self.uncut(direction='previous')
        elif operation == 'uncut_right':
            self.uncut(direction='next')
        elif operation == 'delete':
            self.delete(context.sequences)
        elif operation == 'ripple_delete':
            self.delete(context.sequences, ripple=True)
        
        return{'FINISHED'}

class VSEQFQuickTimeline(bpy.types.Operator):
    """Operator to adjust the VSE timeline in various ways
    
    Argument:
        operation: String, the operation to be performed.
            'sequences': Trims the timeline to all sequences in the VSE.  If no sequences are loaded, timeline is not changed.
            'selected': Trims the timeline to the selected sequence(s) in the VSE.  If no sequences are selected, timeline is not changed.
            'sequences_start': Like 'sequences', but only trims the start frame.
            'sequences_end': Like 'sequences, but only trims the end frame.
            'selected_start': Like 'selected', but only trims the start frame.
            'selected_end': Like 'selected', but only trims the end frame."""

    bl_idname = 'vseqf.quicktimeline'
    bl_label = 'VSEQF Quick Timeline'
    
    operation = bpy.props.StringProperty()
    
    def execute(self, context):
        operation = self.operation
        if 'selected' in operation:
            sequences = context.selected_sequences
        else:
            sequences = context.sequences

        if sequences:
            starts = []
            ends = []
            for sequence in sequences:
                starts.append(sequence.frame_final_start)
                ends.append(sequence.frame_final_end)
            starts.sort()
            ends.sort()
            newstart = starts[0]
            newend = ends[-1] - 1
            scene = context.scene
            if 'start' in operation and not 'end' in operation:
                #only set start point
                if scene.frame_end <= newstart:
                    scene.frame_end = newstart
                scene.frame_start = newstart
            elif 'end'in operation and not 'start' in operation:
                #only set end point
                if scene.frame_start >= newend:
                    scene.frame_start = newend
                scene.frame_end = newend
            else:
                #set start and end
                scene.frame_start = newstart
                scene.frame_end = newend

        return{'FINISHED'}


#Classes for settings and variables
class VSEQFTags(bpy.types.PropertyGroup):
    """QuickTags property that stores tag information"""
    text = bpy.props.StringProperty(
        name = "Tag Text",
        default = "")

class VSEQFMarkerPreset(bpy.types.PropertyGroup):
    """Property for marker presets"""
    text = bpy.props.StringProperty(name="Text", default="")

class VSEQFSequence(bpy.types.PropertyGroup):
    """Used to store some important data about a VSE Sequence to be used later"""
    name = bpy.props.StringProperty(
        name = "Sequence Name")
    frame_final_start = bpy.props.IntProperty()
    frame_final_end = bpy.props.IntProperty()
    parent = bpy.props.StringProperty()
    ignore_continuous = bpy.props.BoolProperty(default=False)

class VSEQFSettingsMenu(bpy.types.Menu):
    """Pop-up menu for settings related to QuickContinuous"""
    bl_idname = "vseqf.settings_menu"
    bl_label = "Quick Settings"

    def draw(self, context):
        if __name__ in bpy.context.user_preferences.addons:
            prefs = bpy.context.user_preferences.addons[__name__].preferences
        else:
            prefs = VSEQFTempSettings()
        
        layout = self.layout
        scene = bpy.context.scene
        layout.prop(scene.vseqf, 'ripple')
        layout.prop(scene.vseqf, 'fix_active')
        if prefs.parenting:
            layout.separator()
            layout.label('QuickParenting Settings')
            layout.separator()
            layout.prop(scene.vseqf, 'children')
            layout.prop(scene.vseqf, 'autoparent')
            layout.prop(scene.vseqf, 'select_children')
            layout.prop(scene.vseqf, 'child_edges')
            layout.prop(scene.vseqf, 'delete_children')
        if prefs.proxy:
            layout.separator()
            layout.label('QuickProxy Settings')
            layout.separator()
            layout.prop(scene.vseqf, 'enable_proxy')
            layout.prop(scene.vseqf, 'build_proxy')
            layout.prop(scene.vseqf, "proxy_quality", text='Proxy Quality')
            layout.prop(scene.vseqf, "proxy_25", text='Generate 25% Proxy')
            layout.prop(scene.vseqf, "proxy_50", text='Generate 50% Proxy')
            layout.prop(scene.vseqf, "proxy_75", text='Generate 75% Proxy')
            layout.prop(scene.vseqf, "proxy_100", text='Generate 100% Proxy')

class VSEQFSetting(bpy.types.PropertyGroup):
    """Property group to store most VSEQF settings.  This will be assigned to scene.vseqf"""
    last_frame = bpy.props.IntProperty(
        name = "Last Scene Frame",
        default = 1)
    video_settings_menu = bpy.props.EnumProperty(
        name = "Video Render Setting",
        default = 'DEFAULT',
        items = [('DEFAULT', 'Scene Settings', '', 1), ('AVIJPEG', 'AVI JPEG', '', 2), ('H264', 'H264 Video', '', 3), ('JPEG', 'JPEG Sequence', '', 4), ('PNG', 'PNG Sequence', '', 5), ('TIFF', 'TIFF Sequence', '', 6), ('EXR', 'Open EXR Sequence', '', 7)])
    transparent_settings_menu = bpy.props.EnumProperty(
        name = "Transparent Video Render Setting",
        default = 'DEFAULT',
        items = [('DEFAULT', 'Scene Settings', '', 1), ('AVIJPEG', 'AVI JPEG (No Transparency)', '', 2), ('H264', 'H264 Video (No Transparency)', '', 3), ('JPEG', 'JPEG Sequence (No Transparency)', '', 4), ('PNG', 'PNG Sequence', '', 5), ('TIFF', 'TIFF Sequence', '', 6), ('EXR', 'Open EXR Sequence', '', 7)])
    audio_settings_menu = bpy.props.EnumProperty(
        name = "Audio Render Setting",
        default = 'FLAC',
        #mp3 export seems to be broken currently, (exports as extremely loud distorted garbage) so "('MP3', 'MP3 File', '', 3), " is removed for now
        items = [('FLAC', 'FLAC Audio', '', 1), ('WAV', 'WAV File', '', 2), ('OGG', 'OGG File', '', 3)])

    continuous_enable = bpy.props.BoolProperty(
        name = "Enable Quick Continuous",
        default = False)
        
    fix_active = bpy.props.BoolProperty(
        name = "Fix Active Strip When Cutting",
        default = True)

    batch_render_directory = bpy.props.StringProperty(
        name = "Render Directory",
        default = './',
        description = "Folder to batch render strips to.",
        subtype='DIR_PATH')
    batch_selected = bpy.props.BoolProperty(
        name = "Render Only Selected",
        default = False)
    batch_effects = bpy.props.BoolProperty(
        name = "Render Modifiers",
        default = True,
        description = "If active, this will render modifiers to the export, if deactivated, modifiers will be copied.")
    batch_audio = bpy.props.BoolProperty(
        name = "Render Audio",
        default = True,
        description = "If active, this will render audio strips to a new file, if deactivated, audio strips will be copied over.")
    batch_meta = bpy.props.EnumProperty(
        name = "Render Meta Strips",
        default = 'SINGLESTRIP',
        items = [('SINGLESTRIP', 'Single Strip', '', 1),('SUBSTRIPS', 'Individual Substrips', '', 2),('IGNORE', 'Ignore', '', 3)])
    batch_rendering = bpy.props.BoolProperty(
        name = "Currently Rendering File",
        default = False)
    batch_rendering_cancel = bpy.props.BoolProperty(
        name = "Canceled A Render",
        default = False)
        
    follow = bpy.props.BoolProperty(
        name = "Cursor Following",
        default = False)
    children = bpy.props.BoolProperty(
        name = "Cut/Move Children",
        default = True,
        description = "Automatically cut and move child strips along with a parent.")
    autoparent = bpy.props.BoolProperty(
        name = "Auto-Parent New Audio To Video",
        default = True,
        description = "Automatically parent audio strips to video when importing a movie with both types of strips.")
    select_children = bpy.props.BoolProperty(
        name = "Auto-Select Children",
        default = False,
        description = "Automatically select child strips when a parent is selected.")
    child_edges = bpy.props.BoolProperty(
        name = "Adjust Child Edges",
        default = True,
        description = "Automatically adjust child strip edges when a parent strip's edges are adjusted.")
    expanded_children = bpy.props.BoolProperty(default=True)
    delete_children = bpy.props.BoolProperty(
        name = "Auto-Delete Children",
        default=False,
        description = "Automatically delete child strips when a parent is deleted.")

    transition = bpy.props.EnumProperty(
        name="Transition Type",
        default="CROSS",
        items=[("CROSS", "Crossfade", "", 1),("WIPE", "Wipe", "", 2),("GAMMA_CROSS", "Gamma Cross", "", 3)])
    fade = bpy.props.IntProperty(
        name = "Fade Length",
        default = 0,
        min = 0,
        description = "Default Fade Length In Frames")
    fadein = bpy.props.IntProperty(
        name = "Fade In Length",
        default = 0,
        min = 0,
        description = "Current Fade In Length In Frames")
    fadeout = bpy.props.IntProperty(
        name = "Fade Out Length",
        default = 0,
        min = 0,
        description = "Current Fade Out Length In Frames")

    quicklist_parenting = bpy.props.BoolProperty(
        name = "Parenting",
        default = True,
        description = 'Display parenting information')
    quicklist_tags = bpy.props.BoolProperty(
        name = "Tags",
        default = True,
        description = 'Display tags')
    quicklist_editing = bpy.props.BoolProperty(
        name = "Settings",
        default = False,
        description = 'Display position, length and proxy settings')
    quicklist_sort_reverse = bpy.props.BoolProperty(
        name = 'Reverse Sort',
        default = False,
        description = 'Reverse sort')
    quicklist_sort = bpy.props.EnumProperty(
        name = "Sort Method",
        default = 'POSITION',
        items = [('POSITION', 'Position', '', 1),('TITLE', 'Title', '', 2),('LENGTH', 'Length', '', 3)])

    enable_proxy = bpy.props.BoolProperty(
        name = "Enable Proxy On Import",
        default = False)
    build_proxy = bpy.props.BoolProperty(
        name = "Auto-Build Proxy On Import",
        default = False)
    proxy_25 = bpy.props.BoolProperty(
        name = "25%",
        default = True)
    proxy_50 = bpy.props.BoolProperty(
        name = "50%",
        default = False)
    proxy_75 = bpy.props.BoolProperty(
        name = "75%",
        default = False)
    proxy_100 = bpy.props.BoolProperty(
        name = "100%",
        default = False)
    proxy_quality = bpy.props.IntProperty(
        name = "Quality",
        default = 90,
        min = 1,
        max = 100)

    marker_index = bpy.props.IntProperty(
        name = "Marker Display Index",
        default = 0)
    marker_presets = bpy.props.CollectionProperty(
        type=VSEQFMarkerPreset)
    expanded_markers = bpy.props.BoolProperty(default=True)
    current_marker = bpy.props.StringProperty(
        name = "New Preset",
        default = '')
    marker_deselect = bpy.props.BoolProperty(
        name = "Deselect New Markers",
        default = True)

    zoom_size = bpy.props.IntProperty(
        name = 'Zoom Amount',
        default = 200,
        min = 1,
        description = "Zoom size in frames",
        update = zoom_cursor)
    step = bpy.props.IntProperty(
        name = "Frame Step",
        default = 0,
        min = 0,
        max = 6)
    last_sequences = bpy.props.CollectionProperty(type=VSEQFSequence)
    ripple = bpy.props.BoolProperty(
        name = "Ripple Editing Mode",
        default=False)
    skip_index = bpy.props.IntProperty(
        default = 0)
    last_sequencer = bpy.props.StringProperty()
    
    current_tag = bpy.props.StringProperty(
        name = "New Tag",
        default = '')
    tags = bpy.props.CollectionProperty(type=VSEQFTags)
    selected_tags = bpy.props.CollectionProperty(type=VSEQFTags)
    show_selected_tags = bpy.props.BoolProperty(
        name = "Show Tags For All Selected Sequences",
        default=False)
    
    quickcuts_insert = bpy.props.IntProperty(
        name = "Frames To Insert",
        default = 0,
        min = 0)
    quickcuts_all = bpy.props.BoolProperty(
        name = 'Cut All Sequences',
        default = False,
        description = 'Cut all sequences, regardless of selection (not including locked sequences)')

class VSEQuickFunctionSettings(bpy.types.AddonPreferences):
    """Addon preferences for QuickFunctions, used to enable and disable features"""
    bl_idname = __name__
    parenting = bpy.props.BoolProperty(
        name="Enable Quick Parenting",
        default=True)
    fades = bpy.props.BoolProperty(
        name="Enable Quick Fades",
        default=True)
    list = bpy.props.BoolProperty(
        name="Enable Quick List",
        default=True)
    proxy = bpy.props.BoolProperty(
        name="Enable Quick Proxy",
        default=True)
    markers = bpy.props.BoolProperty(
        name="Enable Quick Markers",
        default=True)
    batch = bpy.props.BoolProperty(
        name="Enable Quick Batch Render",
        default=True)
    tags = bpy.props.BoolProperty(
        name="Enable Quick Tags",
        default=True)
    cuts = bpy.props.BoolProperty(
        name="Enable Quick Cuts",
        default=True)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "parenting")
        layout.prop(self, "fades")
        layout.prop(self, "list")
        layout.prop(self, "proxy")
        layout.prop(self, "markers")
        layout.prop(self, "batch")
        layout.prop(self, "tags")
        layout.prop(self, "cuts")

class VSEQFTempSettings(object):
    """Substitute for the addon preferences when this script isn't loaded as an addon"""
    parenting = bpy.props.BoolProperty(
        name="Enable Quick Parenting",
        default=True)
    fades = bpy.props.BoolProperty(
        name="Enable Quick Fades",
        default=True)
    list = bpy.props.BoolProperty(
        name="Enable Quick List",
        default=True)
    proxy = bpy.props.BoolProperty(
        name="Enable Quick Proxy",
        default=True)
    markers = bpy.props.BoolProperty(
        name="Enable Quick Markers",
        default=True)
    batch = bpy.props.BoolProperty(
        name="Enable Quick Batch Render",
        default=True)
    tags = bpy.props.BoolProperty(
        name="Enable Quick Tags",
        default=True)
    cuts = bpy.props.BoolProperty(
        name="Enable Quick Cuts",
        default=True)


#Register properties, operators, menus and shortcuts
def register():
    bpy.utils.register_class(VSEQuickFunctionSettings)
    
    #Register operators
    bpy.utils.register_module(__name__)
    
    bpy.types.SEQUENCER_PT_edit.append(edit_panel)
    
    #Add menus
    bpy.types.SEQUENCER_HT_header.append(draw_quickspeed_header)
    bpy.types.SEQUENCER_MT_view.append(draw_quickzoom_menu)
    bpy.types.SEQUENCER_MT_view.prepend(draw_quicksettings_menu)
    bpy.types.SEQUENCER_MT_strip.prepend(draw_quicksnap_menu)

    bpy.types.Scene.total_sequences = bpy.props.IntProperty(
        default = 0)
    bpy.types.Scene.vseqf_skip_interval = bpy.props.IntProperty(
        default=0,
        min=0)

    #New Sequence variables
    bpy.types.Sequence.parent = bpy.props.StringProperty()
    bpy.types.Sequence.last_frame_final_start = bpy.props.IntProperty()
    bpy.types.Sequence.last_frame_start = bpy.props.IntProperty()
    bpy.types.Sequence.last_frame_final_duration = bpy.props.IntProperty()
    bpy.types.Sequence.last_select = bpy.props.BoolProperty()
    bpy.types.Sequence.last_channel = bpy.props.IntProperty()
    bpy.types.Sequence.last_name = bpy.props.StringProperty(default = '')
    bpy.types.Sequence.new = bpy.props.BoolProperty(
        default = True)
    bpy.types.Sequence.ignore_continuous = bpy.props.BoolProperty(default=False)
    bpy.types.Sequence.tags = bpy.props.CollectionProperty(type=VSEQFTags)
    
    #Group properties
    bpy.types.Scene.vseqf = bpy.props.PointerProperty(type=VSEQFSetting)

    #Register shortcuts
    keymap = bpy.context.window_manager.keyconfigs.addon.keymaps.new(name='Sequencer', space_type='SEQUENCE_EDITOR', region_type='WINDOW')
    keymapitems = keymap.keymap_items
    
    for keymapitem in keymapitems:
        #Iterate through keymaps and delete old shortcuts
        if ((keymapitem.type == 'Z') | (keymapitem.type == 'P') | (keymapitem.type == 'F') | (keymapitem.type == 'S')):
            keymapitems.remove(keymapitem)
    keymapmarker = keymapitems.new('wm.call_menu', 'M', 'PRESS', alt=True)
    keymapmarker.properties.name = 'vseqf.quickmarkers_menu'
    keymapzoom = keymapitems.new('wm.call_menu', 'Z', 'PRESS')
    keymapzoom.properties.name = 'vseqf.quickzooms_menu'
    keymapfade = keymapitems.new('wm.call_menu', 'F', 'PRESS')
    keymapfade.properties.name = 'vseqf.quickfades_menu'
    keymapsnap = keymapitems.new('wm.call_menu', 'S', 'PRESS')
    keymapsnap.properties.name = 'vseqf.quicksnaps_menu'
    keymapparent = keymapitems.new('wm.call_menu', 'P', 'PRESS', ctrl=True)
    keymapparent.properties.name = 'vseqf.quickparents_menu'
    keymapparentselect = keymapitems.new('vseqf.quickparents', 'P', 'PRESS', shift=True)
    keymapparentselect.properties.action = 'select_children'
    keymapcuts = keymapitems.new('wm.call_menu', 'K', 'PRESS', alt=True)
    keymapcuts.properties.name = 'vseqf.quickcuts_menu'

    #Register handler and modal operator
    handlers = bpy.app.handlers.frame_change_post
    for handler in handlers:
        if (" frame_step " in str(handler)):
            handlers.remove(handler)
    handlers.append(frame_step)
    handlers = bpy.app.handlers.scene_update_post
    for handler in handlers:
        if (" vseqf_continuous " in str(handler)):
            handlers.remove(handler)
    handlers.append(vseqf_continuous)

def unregister():
    #Unregister menus
    bpy.types.SEQUENCER_HT_header.remove(draw_quickspeed_header)
    bpy.types.SEQUENCER_MT_view.remove(draw_quickzoom_menu)
    bpy.types.SEQUENCER_MT_view.remove(draw_quicksettings_menu)
    bpy.types.SEQUENCER_MT_strip.remove(draw_quicksnap_menu)
    
    bpy.types.SEQUENCER_PT_edit.remove(edit_panel)

    #Remove shortcuts
    keymapitems = bpy.context.window_manager.keyconfigs.addon.keymaps['Sequencer'].keymap_items
    for keymapitem in keymapitems:
        if ((keymapitem.type == 'Z') | (keymapitem.type == 'F') | (keymapitem.type == 'S')):
            keymapitems.remove(keymapitem)
            
    #Remove handlers for modal operators
    handlers = bpy.app.handlers.frame_change_post
    for handler in handlers:
        if (" frame_step " in str(handler)):
            handlers.remove(handler)
    handlers = bpy.app.handlers.scene_update_post
    for handler in handlers:
        if (" vseqf_continuous " in str(handler)):
            handlers.remove(handler)

    try:
        bpy.utils.unregister_class(VSEQuickFunctionSettings)
    except RuntimeError:
        pass

    #Unregister operators
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
